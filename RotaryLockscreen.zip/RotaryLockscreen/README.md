# Rotary Dial Lockscreen for Android

A beautiful vintage rotary dial phone-style lockscreen for Android apps with a cream/beige aesthetic.

![Rotary Lockscreen](screenshot.png)

## Features

- **Authentic Rotary Dial** — Drag to rotate, just like a vintage phone
- **Skeuomorphic Design** — Realistic shadows, gradients, and depth
- **Smooth Animations** — Spring-back animation, shake on wrong code
- **Secure Passcode** — 4-digit PIN with persistent storage
- **Customizable** — Easy to change passcode and colors

## Default Passcode

**`2580`** — Dial 2 → 5 → 8 → 0 to unlock

## Project Structure

```
app/src/main/java/com/example/rotarylockscreen/
├── LockscreenActivity.kt    # Main lockscreen activity
├── MainActivity.kt          # Demo activity after unlock
├── RotaryDialView.kt        # Custom rotary dial view
└── PasscodeManager.kt       # Passcode storage & validation
```

## Integration

### 1. Copy the files to your project

Copy these files to your Android project:
- `RotaryDialView.kt` — Custom view
- `PasscodeManager.kt` — Passcode handling
- `LockscreenActivity.kt` — Lockscreen UI
- All XML resources (layouts, drawables, values)

### 2. Add to your AndroidManifest.xml

```xml
<activity
    android:name=".LockscreenActivity"
    android:screenOrientation="portrait"
    android:windowSoftInputMode="adjustNothing" />
```

### 3. Show the lockscreen

```kotlin
// Show lockscreen
val intent = Intent(this, LockscreenActivity::class.java)
startActivity(intent)
```

### 4. Customize the passcode

```kotlin
val passcodeManager = PasscodeManager(context)
passcodeManager.correctPasscode = "1234"  // Set new passcode
```

### 5. Listen for unlock events

The lockscreen automatically navigates to `MainActivity` on success. To customize:

```kotlin
// In LockscreenActivity.kt, modify onUnlockSuccess()
private fun onUnlockSuccess() {
    // Your custom unlock logic
    startActivity(Intent(this, YourActivity::class.java))
    finish()
}
```

## Customization

### Change Colors

Edit `res/values/colors.xml`:

```xml
<color name="cream">#F5F2ED</color>
<color name="beige">#E0DBD2</color>
<color name="highlight_brown">#8B7355</color>
```

### Change Dial Size

Edit `res/values/dimens.xml`:

```xml
<dimen name="dial_size">320dp</dimen>
```

### Change Passcode Length

In `RotaryDialView.kt` and `LockscreenActivity.kt`, change:

```kotlin
private val passcodeLength = 6  // Instead of 4
```

## Requirements

- Android SDK 24+ (Android 7.0)
- Kotlin 1.9+
- AndroidX

## License

MIT License — Free for personal and commercial use.
