package com.example.rotarylockscreen

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var passcodeManager: PasscodeManager
    private lateinit var currentPasscodeText: EditText
    private lateinit var newPasscodeText: EditText
    private lateinit var updateButton: Button
    private lateinit var lockButton: Button
    private lateinit var titleText: TextView
    private lateinit var currentLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        passcodeManager = PasscodeManager(this)

        titleText = findViewById(R.id.titleText)
        currentLabel = findViewById(R.id.currentLabel)
        currentPasscodeText = findViewById(R.id.currentPasscode)
        newPasscodeText = findViewById(R.id.newPasscode)
        updateButton = findViewById(R.id.updateButton)
        lockButton = findViewById(R.id.lockButton)

        // Check if passcode is already set
        val hasPasscode = passcodeManager.hasPasscode()
        
        if (!hasPasscode) {
            // First time setup
            titleText.text = "Set Up Passcode"
            currentLabel.visibility = View.GONE
            currentPasscodeText.visibility = View.GONE
            updateButton.text = "Set Passcode"
            lockButton.visibility = View.GONE
        }

        updateButton.setOnClickListener {
            val current = currentPasscodeText.text.toString()
            val newPass = newPasscodeText.text.toString()

            if (newPass.length != 4) {
                Toast.makeText(this, "Passcode must be 4 digits", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (hasPasscode) {
                // Updating existing passcode
                if (current.length != 4) {
                    Toast.makeText(this, "Enter current passcode", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (!passcodeManager.isPasscodeCorrect(current)) {
                    Toast.makeText(this, "Current passcode is incorrect", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                passcodeManager.correctPasscode = newPass
                Toast.makeText(this, "Passcode updated successfully!", Toast.LENGTH_SHORT).show()
                currentPasscodeText.text.clear()
                newPasscodeText.text.clear()
            } else {
                // Setting passcode for first time
                passcodeManager.correctPasscode = newPass
                Toast.makeText(this, "Passcode set successfully!", Toast.LENGTH_SHORT).show()
                newPasscodeText.text.clear()
                
                // Show lock button after setup
                lockButton.visibility = View.VISIBLE
                titleText.text = "App Unlocked!"
            }
        }

        lockButton.setOnClickListener {
            val intent = Intent(this, LockscreenActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }
    }
}
