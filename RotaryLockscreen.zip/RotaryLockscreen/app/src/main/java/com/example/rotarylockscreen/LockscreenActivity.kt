package com.example.rotarylockscreen

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnticipateOvershootInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class LockscreenActivity : AppCompatActivity() {

    private lateinit var rotaryDialView: RotaryDialView
    private lateinit var passcodeDotsContainer: LinearLayout
    private lateinit var lockIcon: ImageView
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var statusText: TextView
    private lateinit var successOverlay: View

    private lateinit var passcodeManager: PasscodeManager
    private val enteredPasscode = StringBuilder()
    private val dots = mutableListOf<View>()

    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 60000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lockscreen)

        // Hide system UI
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        passcodeManager = PasscodeManager(this)

        // Check if passcode is set, if not redirect to setup
        if (!passcodeManager.hasPasscode()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        initViews()
        setupRotaryDial()
        createPasscodeDots()
        updateClock()
        handler.post(clockRunnable)
    }

    private fun initViews() {
        rotaryDialView = findViewById(R.id.rotaryDialView)
        passcodeDotsContainer = findViewById(R.id.passcodeDotsContainer)
        lockIcon = findViewById(R.id.lockIcon)
        clockText = findViewById(R.id.clockText)
        dateText = findViewById(R.id.dateText)
        statusText = findViewById(R.id.statusText)
        successOverlay = findViewById(R.id.successOverlay)
    }

    private fun setupRotaryDial() {
        rotaryDialView.onNumberSelectedListener = object : RotaryDialView.OnNumberSelectedListener {
            override fun onNumberSelected(number: Int) {
                onDigitEntered(number)
            }
        }
    }

    private fun createPasscodeDots() {
        passcodeDotsContainer.removeAllViews()
        dots.clear()

        val dotSize = resources.getDimensionPixelSize(R.dimen.passcode_dot_size)
        val dotMargin = resources.getDimensionPixelSize(R.dimen.passcode_dot_margin)

        repeat(4) { index ->
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dotSize, dotSize).apply {
                    marginStart = if (index == 0) 0 else dotMargin
                    marginEnd = if (index == 3) 0 else dotMargin
                }
                background = ContextCompat.getDrawable(this@LockscreenActivity, R.drawable.passcode_dot_empty)
            }
            dots.add(dot)
            passcodeDotsContainer.addView(dot)
        }
    }

    private fun onDigitEntered(digit: Int) {
        if (enteredPasscode.length < 4) {
            enteredPasscode.append(digit)
            updateDots()

            if (enteredPasscode.length == 4) {
                handler.postDelayed({ checkPasscode() }, 200)
            }
        }
    }

    private fun updateDots() {
        dots.forEachIndexed { index, dot ->
            dot.background = if (index < enteredPasscode.length) {
                ContextCompat.getDrawable(this, R.drawable.passcode_dot_filled)
            } else {
                ContextCompat.getDrawable(this, R.drawable.passcode_dot_empty)
            }
        }

        // Animate the newly filled dot
        if (enteredPasscode.isNotEmpty()) {
            val lastIndex = enteredPasscode.length - 1
            dots.getOrNull(lastIndex)?.let { dot ->
                dot.animate()
                    .scaleX(1.3f)
                    .scaleY(1.3f)
                    .setDuration(100)
                    .withEndAction {
                        dot.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(100)
                            .start()
                    }
                    .start()
            }
        }
    }

    private fun checkPasscode() {
        if (passcodeManager.isPasscodeCorrect(enteredPasscode.toString())) {
            onUnlockSuccess()
        } else {
            onUnlockFailed()
        }
    }

    private fun onUnlockSuccess() {
        // Change lock icon to unlocked
        lockIcon.setImageResource(R.drawable.ic_lock_open)
        lockIcon.setColorFilter(ContextCompat.getColor(this, R.color.success_green))

        // Animate lock icon
        lockIcon.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(200)
            .setInterpolator(OvershootInterpolator())
            .withEndAction {
                lockIcon.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(200)
                    .start()
            }
            .start()

        // Show success overlay
        successOverlay.visibility = View.VISIBLE
        successOverlay.animate()
            .alpha(1f)
            .setDuration(300)
            .start()

        // Navigate to main activity
        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 1200)
    }

    private fun onUnlockFailed() {
        // Shake animation on dots
        ObjectAnimator.ofFloat(passcodeDotsContainer, "translationX", 0f, -20f, 20f, -20f, 20f, 0f).apply {
            duration = 400
            start()
        }

        // Shake lock icon
        ObjectAnimator.ofFloat(lockIcon, "translationX", 0f, -10f, 10f, -10f, 10f, 0f).apply {
            duration = 400
            start()
        }

        // Change dots to error color temporarily
        dots.forEach { dot ->
            dot.background = ContextCompat.getDrawable(this, R.drawable.passcode_dot_error)
        }

        // Reset after animation
        handler.postDelayed({
            resetPasscode()
        }, 400)
    }

    private fun resetPasscode() {
        enteredPasscode.clear()
        dots.forEach { dot ->
            dot.background = ContextCompat.getDrawable(this, R.drawable.passcode_dot_empty)
        }
        rotaryDialView.reset()
    }

    private fun updateClock() {
        val calendar = Calendar.getInstance()

        // Update time
        val timeFormat = SimpleDateFormat("h:mm", Locale.getDefault())
        clockText.text = timeFormat.format(calendar.time)

        // Update date
        val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        dateText.text = dateFormat.format(calendar.time)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(clockRunnable)
    }

    override fun onBackPressed() {
        // Prevent back button from exiting lockscreen
    }
}
