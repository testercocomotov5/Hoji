package com.sgyt.guardianblock.data.repository

import com.sgyt.guardianblock.data.local.PreferencesManager
import com.sgyt.guardianblock.domain.model.BlockConfig
import com.sgyt.guardianblock.domain.repository.BlockRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class BlockRepositoryImpl @Inject constructor(
    private val prefsManager: PreferencesManager
) : BlockRepository {
    override fun getBlockConfig(): Flow<BlockConfig>          = prefsManager.getBlockConfig()
    override suspend fun saveBlockConfig(config: BlockConfig) = prefsManager.saveBlockConfig(config)
    override suspend fun addKeyword(keyword: String)          = prefsManager.addKeyword(keyword)
    override suspend fun removeKeyword(keyword: String)       = prefsManager.removeKeyword(keyword)
    override suspend fun getPinHash(): String                 = prefsManager.getPinHash()
    override suspend fun savePinHash(hash: String)            = prefsManager.savePinHash(hash)
}
