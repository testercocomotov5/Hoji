package com.sgyt.guardianblock.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sgyt.guardianblock.ui.dashboard.DashboardScreen
import com.sgyt.guardianblock.ui.query.DnsQueryScreen
import com.sgyt.guardianblock.ui.settings.SettingsScreen

/**
 * FUSION: startDestination is now Dashboard.
 * The Compose LockScreen route is removed; the native RotaryLockscreenActivity
 * handles authentication before this NavHost is ever shown.
 */
@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    NavHost(
        navController       = nav,
        startDestination    = Screen.Dashboard.route,
        enterTransition     = { fadeIn(tween(280)) + slideInHorizontally(tween(280)) { it / 4 } },
        exitTransition      = { fadeOut(tween(200)) + slideOutHorizontally(tween(200)) { -it / 4 } },
        popEnterTransition  = { fadeIn(tween(280)) + slideInHorizontally(tween(280)) { -it / 4 } },
        popExitTransition   = { fadeOut(tween(200)) + slideOutHorizontally(tween(200)) { it / 4 } }
    ) {
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onNavigateToSettings = { nav.navigate(Screen.Settings.route) },
                onNavigateToQueries  = { nav.navigate(Screen.Queries.route) }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(onNavigateBack = { nav.popBackStack() })
        }
        composable(Screen.Queries.route) {
            DnsQueryScreen(onNavigateBack = { nav.popBackStack() })
        }
    }
}
