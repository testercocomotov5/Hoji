package com.sgyt.guardianblock.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.sgyt.guardianblock.ui.theme.ThemeManager.AppTheme

// Light Theme - Standard
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFE30613),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF2DEE0),
    onPrimaryContainer = Color(0xFFB90524),
    secondary = Color(0xFF3A3A3A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8E8E8),
    onSecondaryContainer = Color(0xFF1A1A1A),
    tertiary = Color(0xFF1A5FB4),
    onTertiary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF1A1A1A),
    surface = Color.White,
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = Color(0xFFF7F7F7),
    onSurfaceVariant = Color(0xFF3A3A3A),
    error = Color(0xFFE30613),
    onError = Color.White,
    errorContainer = Color(0xFFF2DEE0),
    onErrorContainer = Color(0xFFB90524),
    outline = Color(0xFFB0B0B0),
    outlineVariant = Color(0xFFE8E8E8)
)

// Dark Theme - Standard
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFE30613),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB90524),
    onPrimaryContainer = Color(0xFFF2DEE0),
    secondary = Color(0xFFB0B0B0),
    onSecondary = Color(0xFF1A1A1A),
    secondaryContainer = Color(0xFF3A3A3A),
    onSecondaryContainer = Color(0xFFE8E8E8),
    tertiary = Color(0xFF1A5FB4),
    onTertiary = Color.White,
    background = Color(0xFF1A1A1A),
    onBackground = Color.White,
    surface = Color(0xFF2A2A2A),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF3A3A3A),
    onSurfaceVariant = Color(0xFFB0B0B0),
    error = Color(0xFFE30613),
    onError = Color.White,
    errorContainer = Color(0xFFB90524),
    onErrorContainer = Color(0xFFF2DEE0),
    outline = Color(0xFFB0B0B0),
    outlineVariant = Color(0xFF3A3A3A)
)

// Swiss Light Theme
private val SwissLightColorScheme = lightColorScheme(
    primary = SwissRed,
    onPrimary = SwissWhite,
    primaryContainer = SwissRedLight,
    onPrimaryContainer = SwissRedDark,
    secondary = SwissDarkGray,
    onSecondary = SwissWhite,
    secondaryContainer = SwissLightGray,
    onSecondaryContainer = SwissCharcoal,
    tertiary = SwissBlue,
    onTertiary = SwissWhite,
    tertiaryContainer = SwissBlueLight,
    onTertiaryContainer = SwissBlue,
    background = SwissWhite,
    onBackground = SwissCharcoal,
    surface = SwissWhite,
    onSurface = SwissCharcoal,
    surfaceVariant = SwissOffWhite,
    onSurfaceVariant = SwissDarkGray,
    surfaceTint = SwissRed,
    error = SwissRed,
    onError = SwissWhite,
    errorContainer = SwissRedLight,
    onErrorContainer = SwissRedDark,
    outline = SwissMidGray,
    outlineVariant = SwissLightGray
)

// Swiss Dark Theme
private val SwissDarkColorScheme = darkColorScheme(
    primary = SwissRed,
    onPrimary = SwissWhite,
    primaryContainer = SwissRedDark,
    onPrimaryContainer = SwissRedLight,
    secondary = SwissMidGray,
    onSecondary = SwissCharcoal,
    secondaryContainer = SwissDarkGray,
    onSecondaryContainer = SwissLightGray,
    tertiary = SwissBlue,
    onTertiary = SwissWhite,
    tertiaryContainer = Color(0xFF0D3A6E),
    onTertiaryContainer = SwissBlueLight,
    background = SwissCharcoal,
    onBackground = SwissWhite,
    surface = Color(0xFF2A2A2A),
    onSurface = SwissWhite,
    surfaceVariant = SwissDarkGray,
    onSurfaceVariant = SwissMidGray,
    surfaceTint = SwissRed,
    error = SwissRed,
    onError = SwissWhite,
    errorContainer = SwissRedDark,
    onErrorContainer = SwissRedLight,
    outline = SwissMidGray,
    outlineVariant = SwissDarkGray
)

/**
 * CompositionLocal for accessing the current app theme throughout the composition tree.
 * This enables screens to react to theme changes without passing the theme as a parameter.
 */
val LocalAppTheme = compositionLocalOf { AppTheme.SWISS_LIGHT }

/**
 * ThemeColors provides theme-aware colors for the app.
 * These colors automatically adapt based on the current theme (light/dark).
 */
data class ThemeColors(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textDisabled: Color,
    val accent: Color,
    val success: Color,
    val border: Color,
    val borderLight: Color
)

/**
 * Returns theme-aware colors based on the current app theme.
 * Use this composable to access colors that automatically adapt to light/dark mode.
 */
@Composable
fun themeColors(): ThemeColors {
    val theme = LocalAppTheme.current
    val isDark = theme == AppTheme.DARK || theme == AppTheme.SWISS_DARK
    return ThemeColors(
        background = if (isDark) Color(0xFF1A1A1A) else Color.White,
        surface = if (isDark) Color(0xFF2A2A2A) else Color(0xFFF5F5F5),
        surfaceVariant = if (isDark) Color(0xFF3A3A3A) else Color(0xFFF0F0F0),
        textPrimary = if (isDark) Color.White else Color(0xFF1A1A1A),
        textSecondary = if (isDark) Color(0xFFB0B0B0) else Color(0xFF666666),
        textDisabled = if (isDark) Color(0xFF666666) else Color(0xFF999999),
        accent = Color(0xFFE30613), // Swiss Red stays the same
        success = Color(0xFF00843D),
        border = if (isDark) Color(0xFF3A3A3A) else Color(0xFFE0E0E0),
        borderLight = if (isDark) Color(0xFF4A4A4A) else Color(0xFFF0F0F0)
    )
}

/**
 * GuardianBlockTheme - Main theme composable that supports multiple theme options
 *
 * @param theme The app theme to apply
 * @param content The content to be themed
 */
@Composable
fun GuardianBlockTheme(
    theme: AppTheme = AppTheme.SWISS_LIGHT,
    content: @Composable () -> Unit
) {
    val colorScheme = when (theme) {
        AppTheme.LIGHT -> LightColorScheme
        AppTheme.DARK -> DarkColorScheme
        AppTheme.SWISS_LIGHT -> SwissLightColorScheme
        AppTheme.SWISS_DARK -> SwissDarkColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars =
                theme == AppTheme.LIGHT || theme == AppTheme.SWISS_LIGHT
        }
    }

    CompositionLocalProvider(LocalAppTheme provides theme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content
        )
    }
}

/**
 * Legacy theme composable for backwards compatibility
 * Uses Swiss Light theme by default
 */
@Composable
fun GuardianBlockTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = SwissWhite.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
        }
    }

    MaterialTheme(
        colorScheme = SwissLightColorScheme,
        typography = AppTypography,
        content = content
    )
}
