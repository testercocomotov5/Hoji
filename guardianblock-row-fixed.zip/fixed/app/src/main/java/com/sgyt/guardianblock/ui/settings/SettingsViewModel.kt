package com.sgyt.guardianblock.ui.settings

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sgyt.guardianblock.domain.model.BlockConfig
import com.sgyt.guardianblock.domain.repository.BlockRepository
import com.sgyt.guardianblock.domain.usecase.GetBlockConfigUseCase
import com.sgyt.guardianblock.domain.usecase.SaveBlockConfigUseCase
import com.sgyt.guardianblock.service.GuardianAccessibilityService
import com.sgyt.guardianblock.ui.theme.ThemeManager
import com.sgyt.guardianblock.util.AppVisibilityUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val config: BlockConfig = BlockConfig(),
    val isDeviceAdminActive: Boolean = false,
    val isAccessibilityEnabled: Boolean = false,
    val isLoading: Boolean = true,
    val toastMessage: String? = null,
    val requestAdminIntent: Intent? = null,
    val newKeywordText: String = "",
    val currentTheme: ThemeManager.AppTheme = ThemeManager.AppTheme.SWISS_LIGHT
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val getConfig: GetBlockConfigUseCase,
    private val saveConfig: SaveBlockConfigUseCase,
    private val repository: BlockRepository,
    private val appVisibility: AppVisibilityUtil,
    private val themeManager: ThemeManager
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState())
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            getConfig().collect { cfg ->
                _state.value = _state.value.copy(
                    config = cfg,
                    isDeviceAdminActive = appVisibility.isDeviceAdminActive(),
                    isAccessibilityEnabled = GuardianAccessibilityService.isEnabled(context),
                    isLoading = false
                )
            }
        }

        // Observe theme changes
        viewModelScope.launch {
            themeManager.appTheme.collect { theme ->
                _state.update { it.copy(currentTheme = theme) }
            }
        }
    }

    fun onNewKeywordChanged(text: String) {
        _state.value = _state.value.copy(newKeywordText = text.lowercase().trim())
    }

    fun addKeyword() {
        val kw = _state.value.newKeywordText.trim().lowercase()
        if (kw.isEmpty()) return
        if (kw in _state.value.config.keywords) {
            _state.value = _state.value.copy(toastMessage = "\"$kw\" already exists.")
            return
        }
        viewModelScope.launch {
            repository.addKeyword(kw)
            _state.value = _state.value.copy(newKeywordText = "", toastMessage = "\"$kw\" added.")
        }
    }

    fun removeKeyword(keyword: String) {
        if (keyword in BlockConfig.PROTECTED_KEYWORDS) {
            _state.value = _state.value.copy(toastMessage = "\"$keyword\" is protected.")
            return
        }
        viewModelScope.launch {
            repository.removeKeyword(keyword)
            _state.value = _state.value.copy(toastMessage = "\"$keyword\" removed.")
        }
    }

    fun toggleKeyword(keyword: String, enabled: Boolean) {
        viewModelScope.launch {
            val updated = _state.value.config.keywords.toMutableMap().also { it[keyword] = enabled }
            saveConfig(_state.value.config.copy(keywords = updated))
        }
    }

    fun requestDeviceAdmin() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, appVisibility.getAdminComponent())
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Required to prevent unauthorized removal of system security components."
            )
        }
        _state.value = _state.value.copy(requestAdminIntent = intent)
    }

    fun onAdminActivated() {
        _state.value = _state.value.copy(
            isDeviceAdminActive = true,
            requestAdminIntent = null,
            toastMessage = "Uninstall protection enabled."
        )
    }

    fun onAdminDenied() {
        _state.value = _state.value.copy(requestAdminIntent = null)
    }

    fun clearAdminIntentRequest() {
        _state.value = _state.value.copy(requestAdminIntent = null)
    }

    fun refreshAccessibilityState() {
        _state.value = _state.value.copy(
            isAccessibilityEnabled = GuardianAccessibilityService.isEnabled(context)
        )
    }

    fun clearToast() {
        _state.value = _state.value.copy(toastMessage = null)
    }

    // Theme management
    fun setTheme(theme: ThemeManager.AppTheme) {
        viewModelScope.launch {
            themeManager.setTheme(theme)
            _state.update { it.copy(toastMessage = "Theme changed to ${theme.displayName}") }
        }
    }

    fun getAvailableThemes(): List<ThemeManager.AppTheme> {
        return ThemeManager.AppTheme.values().toList()
    }
}
