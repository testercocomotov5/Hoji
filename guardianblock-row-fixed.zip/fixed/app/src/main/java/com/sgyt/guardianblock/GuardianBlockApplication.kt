package com.sgyt.guardianblock

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GuardianBlockApplication : Application()
