package com.sgyt.guardianblock.ui.pin

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.*

private val SwissRed = Color(0xFFE30613)

@Composable
fun PinScreen(
    onAuthenticated: () -> Unit,
    viewModel: PinViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.isAuthenticated) {
        if (state.isAuthenticated) onAuthenticated()
    }

    val shakeTransition by animateFloatAsState(
        targetValue = if (state.showError) 1f else 0f,
        animationSpec = if (state.showError) keyframes {
            durationMillis = 500
            0f at 0; 1f at 60; -0.8f at 120; 0.6f at 180; -0.4f at 240; 0.2f at 280; 0f at 500
        } else tween(0),
        label = "shake"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterVertically)
        ) {
            // Lock icon
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF5F5F5)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, null, tint = Color(0xFFE30613), modifier = Modifier.size(32.dp))
            }

            // Title
            Text(
                if (state.pinHash.isEmpty()) "Set PIN" else "Enter PIN",
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                color = Color(0xFF1A1A1A),
                letterSpacing = (-0.4).sp
            )

            Text(
                if (state.pinHash.isEmpty()) "Create a 4-digit code" else "Enter your code",
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF999999)
            )

            // PIN dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.graphicsLayer {
                    translationX = shakeTransition * 12f
                }
            ) {
                repeat(4) { i ->
                    val filled = i < state.enteredPin.length
                    val dotColor = when {
                        state.showError -> SwissRed
                        filled -> SwissRed
                        else -> Color(0xFFE0E0E0)
                    }
                    Box(
                        Modifier
                            .size(if (filled) 14.dp else 12.dp)
                            .background(dotColor, CircleShape)
                    )
                }
            }

            // Error label
            AnimatedVisibility(
                visible = state.showError,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200))
            ) {
                Text("Wrong code", color = SwissRed, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(Modifier.height(12.dp))

            // ── Rotary Dial ──────────────────────────────────────────
            RotaryDial(
                digits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                onDigitSelected = { digit ->
                    if (digit.isNotEmpty()) {
                        viewModel.onDigitEntered(digit)
                    }
                }
            )

            // Backspace
            AnimatedVisibility(
                visible = state.enteredPin.isNotEmpty(),
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200))
            ) {
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { viewModel.onBackspace() }
                        .padding(10.dp)
                ) {
                    Text("⌫", fontSize = 20.sp, color = Color(0xFF999999), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RotaryDial(
    digits: List<String>,
    onDigitSelected: (String) -> Unit
) {
    var activeHole by remember { mutableStateOf<Int?>(null) }
    var dialRotation by remember { mutableStateOf(0f) }
    var isReturning by remember { mutableStateOf(false) }

    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        digits.forEach { digit ->
            RotaryHole(
                digit = digit,
                isActive = false,
                onClick = {
                    onDigitSelected(digit)
                }
            )
        }
    }
}

@Composable
private fun RotaryHole(
    digit: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 1.15f else 1f,
        animationSpec = tween(100),
        label = "holeScale"
    )

    Box(
        Modifier
            .size(52.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClick() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.matchParentSize()) {
            val r = size.minDimension / 2f
            drawCircle(color = Color(0xFFE8E8E8), style = Stroke(width = 2f))
            drawCircle(
                color = if (isActive) Color(0xFFF0E0E0) else Color.White,
                radius = r * 0.65f
            )
        }
        Text(
            digit,
            fontSize = 18.sp,
            color = Color(0xFF3A3A3A),
            fontWeight = FontWeight.Medium
        )
    }
}
