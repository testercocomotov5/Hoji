package com.sgyt.guardianblock.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DnsQueryDao {
    @Query("SELECT * FROM dns_queries ORDER BY timestamp DESC")
    fun getAllQueries(): Flow<List<DnsQueryEntity>>

    @Query("SELECT * FROM dns_queries WHERE blocked = 1 ORDER BY timestamp DESC")
    fun getBlockedQueries(): Flow<List<DnsQueryEntity>>

    @Query("SELECT * FROM dns_queries WHERE blocked = 0 ORDER BY timestamp DESC")
    fun getAllowedQueries(): Flow<List<DnsQueryEntity>>

    @Query("SELECT COUNT(*) FROM dns_queries WHERE blocked = 1")
    fun getBlockedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM dns_queries")
    fun getTotalCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuery(query: DnsQueryEntity)

    @Query("DELETE FROM dns_queries")
    suspend fun deleteAll()

    @Query("DELETE FROM dns_queries WHERE timestamp < :olderThan")
    suspend fun deleteOlderThan(olderThan: Long)

    @Query("DELETE FROM dns_queries WHERE id = :id")
    suspend fun deleteById(id: Long)
}
