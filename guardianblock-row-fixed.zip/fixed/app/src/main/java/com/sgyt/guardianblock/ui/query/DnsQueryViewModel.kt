package com.sgyt.guardianblock.ui.query

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sgyt.guardianblock.data.DnsQueryStore
import com.sgyt.guardianblock.domain.model.DnsQuery
import com.sgyt.guardianblock.service.PrivateDnsService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

data class DnsQueryState(
    val queries: List<DnsQuery> = emptyList()
)

@HiltViewModel
class DnsQueryViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val store: DnsQueryStore
) : ViewModel() {

    private val _state = MutableStateFlow(DnsQueryState())
    val state: StateFlow<DnsQueryState> = _state.asStateFlow()

    var liveEnabled by mutableStateOf(true)

    private var dnsQueryReceiver: BroadcastReceiver? = null

    init {
        viewModelScope.launch {
            store.queries.collect { _state.value = _state.value.copy(queries = it) }
        }

        dnsQueryReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == PrivateDnsService.ACTION_DNS_QUERY) {
                    if (!liveEnabled) return
                    val domain = intent.getStringExtra(PrivateDnsService.EXTRA_DOMAIN) ?: return
                    val blocked = intent.getBooleanExtra(PrivateDnsService.EXTRA_BLOCKED, false)
                    viewModelScope.launch {
                        store.add(domain, blocked)
                    }
                }
            }
        }

        ContextCompat.registerReceiver(
            context,
            dnsQueryReceiver,
            IntentFilter(PrivateDnsService.ACTION_DNS_QUERY),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onCleared() {
        super.onCleared()
        dnsQueryReceiver?.let {
            context.unregisterReceiver(it)
        }
    }

    fun deleteQuery(id: Long) {
        viewModelScope.launch {
            store.deleteQuery(id)
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            store.clearAll()
        }
    }
}
