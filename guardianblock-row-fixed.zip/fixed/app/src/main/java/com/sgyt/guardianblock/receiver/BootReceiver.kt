package com.sgyt.guardianblock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.sgyt.guardianblock.data.local.PreferencesManager
import com.sgyt.guardianblock.service.PrivateDnsService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Starts the Private DNS blocking service automatically on every device reboot.
 */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var prefsManager: PreferencesManager

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON") return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val config = prefsManager.getBlockConfig().first()
                if (config.isDnsEnabled) {
                    val permIntent = VpnService.prepare(context)
                    if (permIntent == null) {
                        // Permission already granted – start service
                        context.startForegroundService(
                            Intent(context, PrivateDnsService::class.java).apply {
                                action = PrivateDnsService.ACTION_START
                            }
                        )
                        // Schedule watchdog
                        DnsWatchdogReceiver.schedule(context)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
