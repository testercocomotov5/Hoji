package com.sgyt.guardianblock.ui.theme

import androidx.compose.ui.graphics.Color

// =====================================================
// SWISS THEME COLOR SYSTEM
// =====================================================

// -----------------------------------------------------
// BASE COLORS - Swiss Design Palette
// -----------------------------------------------------

// Swiss whites - crisp, light, minimal
val SwissWhite = Color(0xFFFFFFFF)
val SwissOffWhite = Color(0xFFF7F7F7)
val SwissLightGray = Color(0xFFE8E8E8)
val SwissMidGray = Color(0xFFB0B0B0)
val SwissDarkGray = Color(0xFF3A3A3A)
val SwissCharcoal = Color(0xFF1A1A1A)

// Swiss Red - Primary accent
val SwissRed = Color(0xFFE30613)
val SwissRedDark = Color(0xFFB90524)
val SwissRedLight = Color(0xFFF2DEE0)

// Status colors
val SwissGreen = Color(0xFF00843D)
val SwissGreenLight = Color(0xFFE8F5E9)
val SwissAmber = Color(0xFFFFB300)
val SwissAmberLight = Color(0xFFFFF8E1)
val SwissBlue = Color(0xFF1A5FB4)
val SwissBlueLight = Color(0xFFE3F2FD)

// -----------------------------------------------------
// LIGHT THEME COLORS
// -----------------------------------------------------

object SwissLightColors {
    // Primary brand
    val primary = SwissRed
    val onPrimary = SwissWhite
    val primaryContainer = SwissRedLight
    val onPrimaryContainer = SwissRedDark

    // Secondary
    val secondary = SwissDarkGray
    val onSecondary = SwissWhite
    val secondaryContainer = SwissLightGray
    val onSecondaryContainer = SwissCharcoal

    // Tertiary
    val tertiary = SwissBlue
    val onTertiary = SwissWhite
    val tertiaryContainer = SwissBlueLight
    val onTertiaryContainer = SwissBlue

    // Background
    val background = SwissWhite
    val onBackground = SwissCharcoal

    // Surface
    val surface = SwissWhite
    val onSurface = SwissCharcoal
    val surfaceVariant = SwissOffWhite
    val onSurfaceVariant = SwissDarkGray
    val surfaceTint = SwissRed

    // Outline
    val outline = SwissMidGray
    val outlineVariant = SwissLightGray

    // Error
    val error = SwissRed
    val onError = SwissWhite
    val errorContainer = SwissRedLight
    val onErrorContainer = SwissRedDark

    // Success
    val success = SwissGreen
    val onSuccess = SwissWhite
    val successContainer = SwissGreenLight
    val onSuccessContainer = SwissGreen

    // Warning
    val warning = SwissAmber
    val onWarning = SwissCharcoal
    val warningContainer = SwissAmberLight
    val onWarningContainer = SwissAmber

    // Inverse
    val inverseSurface = SwissCharcoal
    val inverseOnSurface = SwissWhite
    val inversePrimary = SwissRed

    // Scrim
    val scrim = SwissCharcoal
}

// -----------------------------------------------------
// DARK THEME COLORS
// -----------------------------------------------------

object SwissDarkColors {
    // Primary brand
    val primary = SwissRed
    val onPrimary = SwissWhite
    val primaryContainer = SwissRedDark
    val onPrimaryContainer = SwissRedLight

    // Secondary
    val secondary = SwissMidGray
    val onSecondary = SwissCharcoal
    val secondaryContainer = SwissDarkGray
    val onSecondaryContainer = SwissLightGray

    // Tertiary
    val tertiary = SwissBlue
    val onTertiary = SwissWhite
    val tertiaryContainer = Color(0xFF0D3A6E)
    val onTertiaryContainer = SwissBlueLight

    // Background
    val background = SwissCharcoal
    val onBackground = SwissWhite

    // Surface
    val surface = Color(0xFF2A2A2A)
    val onSurface = SwissWhite
    val surfaceVariant = SwissDarkGray
    val onSurfaceVariant = SwissMidGray
    val surfaceTint = SwissRed

    // Outline
    val outline = SwissMidGray
    val outlineVariant = SwissDarkGray

    // Error
    val error = SwissRed
    val onError = SwissWhite
    val errorContainer = SwissRedDark
    val onErrorContainer = SwissRedLight

    // Success
    val success = SwissGreen
    val onSuccess = SwissWhite
    val successContainer = Color(0xFF1B4D2E)
    val onSuccessContainer = SwissGreenLight

    // Warning
    val warning = SwissAmber
    val onWarning = SwissCharcoal
    val warningContainer = Color(0xFF4D3D00)
    val onWarningContainer = SwissAmberLight

    // Inverse
    val inverseSurface = SwissWhite
    val inverseOnSurface = SwissCharcoal
    val inversePrimary = SwissRedDark

    // Scrim
    val scrim = Color(0xFF000000)
}

// -----------------------------------------------------
// SEMANTIC COLORS
// -----------------------------------------------------

// Status and semantic colors for both themes
data class SemanticColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val warning: Color,
    val onWarning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val info: Color,
    val onInfo: Color,
    val infoContainer: Color,
    val onInfoContainer: Color,
)

val LightSemanticColors = SemanticColors(
    success = SwissGreen,
    onSuccess = SwissWhite,
    successContainer = SwissGreenLight,
    onSuccessContainer = SwissGreen,
    warning = SwissAmber,
    onWarning = SwissCharcoal,
    warningContainer = SwissAmberLight,
    onWarningContainer = SwissAmber,
    info = SwissBlue,
    onInfo = SwissWhite,
    infoContainer = SwissBlueLight,
    onInfoContainer = SwissBlue
)

val DarkSemanticColors = SemanticColors(
    success = SwissGreen,
    onSuccess = SwissWhite,
    successContainer = Color(0xFF1B4D2E),
    onSuccessContainer = SwissGreenLight,
    warning = SwissAmber,
    onWarning = SwissCharcoal,
    warningContainer = Color(0xFF4D3D00),
    onWarningContainer = SwissAmberLight,
    info = SwissBlue,
    onInfo = SwissWhite,
    infoContainer = Color(0xFF0D3A6E),
    onInfoContainer = SwissBlueLight
)

// -----------------------------------------------------
// LEGACY COLOR DEFINITIONS (for backwards compatibility)
// -----------------------------------------------------

// Text colors
val TextMain = Color(0xFF1A1A1A)
val TextSub = Color(0xFF777777)
val TextHint = Color(0xFFAAAAAA)

// Dark mode text
val TextMainDark = Color(0xFFFFFFFF)
val TextSubDark = Color(0xFFB0B0B0)
val TextHintDark = Color(0xFF777777)
