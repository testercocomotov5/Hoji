package com.sgyt.guardianblock.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.sgyt.guardianblock.MainActivity
import com.sgyt.guardianblock.data.local.PreferencesManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramSocket
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject

/**
 * PrivateDnsService v9 — live keyword reload + all prior fixes
 *
 * Bug fixes in v9:
 *
 *   [BUG-L FIX] Keywords are now observed via a live Flow coroutine ([keywordObserverJob]).
 *               Previously, keywords were read once at tunnel start and never refreshed.
 *               The user could add/remove/toggle keywords in Settings and the running
 *               service would silently continue using the stale list until a full restart.
 *               Now [liveKeywords] is updated atomically whenever the DataStore config
 *               changes — no service restart required.
 *
 * DNS forwarding path:
 *   TUN (10.99.0.2:53) → DnsInterceptor → SystemDnsProvider (device's own DNS) → protected socket
 *
 * Everything else is identical to v8.
 */
@AndroidEntryPoint
class PrivateDnsService : VpnService() {

    companion object {
        const val ACTION_START        = "com.sgyt.guardianblock.START_DNS"
        const val ACTION_STOP         = "com.sgyt.guardianblock.STOP_DNS"
        const val ACTION_STATS_UPDATE = "com.sgyt.guardianblock.STATS_UPDATE"
        const val EXTRA_BLOCKED_COUNT = "blocked_count"
        const val ACTION_DNS_QUERY    = "com.sgyt.guardianblock.DNS_QUERY"
        const val EXTRA_DOMAIN        = "extra_domain"
        const val EXTRA_BLOCKED       = "extra_blocked"

        const val NOTIFICATION_ID     = 1001
        const val CHANNEL_ID          = "gb_dns_channel"

        private const val MAX_RETRIES    = 3
        private const val RETRY_DELAY    = 500L
        private const val STATS_INTERVAL = 3_000L
    }

    @Inject lateinit var prefsManager:      PreferencesManager
    @Inject lateinit var systemDnsProvider: SystemDnsProvider

    private var vpnInterface: ParcelFileDescriptor? = null

    private var serviceScope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val exceptionHandler = CoroutineExceptionHandler { _, _ ->
        if (isRunning) serviceScope.launch { restartTunnel() }
    }

    private var processingJob:     Job? = null
    private var statsJob:          Job? = null
    private var keywordObserverJob: Job? = null   // BUG-L fix

    @Volatile private var isRunning = false
    private val blockedCount = AtomicInteger(0)

    // BUG-L FIX: keywords stored atomically so the packet loop always reads the latest list
    private val liveKeywords = AtomicReference<List<String>>(emptyList())

    private lateinit var dnsInterceptor: DnsInterceptor

    // ── Network callback — invalidates DNS cache on network change ────────────
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = systemDnsProvider.invalidate()
        override fun onLost(network: Network)      = systemDnsProvider.invalidate()
        override fun onLinkPropertiesChanged(
            network: Network,
            lp: android.net.LinkProperties
        ) = systemDnsProvider.invalidate()
    }

    override fun onCreate() {
        super.onCreate()
        serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO + exceptionHandler)

        dnsInterceptor = DnsInterceptor(
            systemDns        = systemDnsProvider,
            protectUdpSocket = { socket: DatagramSocket -> protect(socket) },
            protectTcpSocket = { socket: java.net.Socket -> protect(socket) },
            onDomainBlocked  = { blockedCount.incrementAndGet() },
            onQuery          = { domain, blocked ->
                try {
                    sendBroadcast(
                        Intent(ACTION_DNS_QUERY)
                            .putExtra(EXTRA_DOMAIN, domain)
                            .putExtra(EXTRA_BLOCKED, blocked)
                            .setPackage(packageName)
                    )
                } catch (_: Exception) {}
            }
        )

        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            cm.registerNetworkCallback(NetworkRequest.Builder().build(), networkCallback)
        } catch (_: Exception) { /* non-fatal */ }

        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopDns(); return START_NOT_STICKY
        }
        if (!promoteToForeground()) { stopSelf(); return START_NOT_STICKY }
        startDns()
        return START_STICKY
    }

    // ── Foreground ────────────────────────────────────────────────────────────

    private fun promoteToForeground(): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        true
    } catch (_: Exception) { false }

    // ── DNS tunnel lifecycle ──────────────────────────────────────────────────

    private fun startDns() {
        stopPreviousJobs()
        blockedCount.set(0)

        // BUG-L FIX: observe the config Flow continuously and update liveKeywords on every change.
        // This coroutine runs for the lifetime of the DNS session and requires no restart.
        keywordObserverJob = serviceScope.launch {
            prefsManager.getBlockConfig().collect { config ->
                liveKeywords.set(
                    config.keywords.filter { it.value }.keys.toList()
                )
            }
        }

        processingJob = serviceScope.launch(exceptionHandler) { restartTunnel() }
        startStatsJob()
    }

    private suspend fun restartTunnel() {
        var tun: ParcelFileDescriptor? = null
        for (attempt in 0 until MAX_RETRIES) {
            tun = tryEstablish()
            if (tun != null) break
            if (attempt < MAX_RETRIES - 1) delay(RETRY_DELAY * (attempt + 1))
        }
        if (tun == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        vpnInterface = tun
        isRunning    = true
        processPackets()
    }

    private fun tryEstablish(): ParcelFileDescriptor? = try {
        Builder()
            .setSession("GuardianBlock-DNS")
            .addAddress("10.99.0.1", 32)
            .addDnsServer("10.99.0.2")
            .addRoute("10.99.0.2", 32)
            .setMtu(1500)
            .setBlocking(true)
            .establish()
    } catch (_: Exception) { null }

    // ── Concurrent packet processing ─────────────────────────────────────────

    private suspend fun processPackets() {
        val pfd       = vpnInterface ?: return
        val input     = FileInputStream(pfd.fileDescriptor)
        val output    = FileOutputStream(pfd.fileDescriptor)
        val writeLock = Mutex()
        val readBuf   = ByteArray(32767)

        try {
            supervisorScope {
                while (isRunning) {
                    val length = withContext(Dispatchers.IO) { input.read(readBuf) }
                    if (length < 0) break
                    if (length == 0) continue

                    val packet = readBuf.copyOfRange(0, length)

                    launch(Dispatchers.IO) {
                        try {
                            // BUG-L FIX: always read the latest keywords atomically.
                            val keywords = liveKeywords.get()
                            val response = dnsInterceptor.process(packet, keywords)
                            if (response != null) {
                                writeLock.withLock {
                                    try { output.write(response) } catch (_: Exception) {}
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {}

        if (isRunning) throw RuntimeException("TUN loop exited unexpectedly")
    }

    private fun stopDns() {
        isRunning = false
        stopPreviousJobs()
        closeTun()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopPreviousJobs() {
        processingJob?.cancel();      processingJob      = null
        statsJob?.cancel();           statsJob           = null
        keywordObserverJob?.cancel(); keywordObserverJob = null
    }

    private fun closeTun() {
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
    }

    override fun onRevoke() { isRunning = false; closeTun() }

    override fun onDestroy() {
        isRunning = false
        stopPreviousJobs()
        closeTun()
        try {
            getSystemService(ConnectivityManager::class.java)
                .unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {}
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Stats broadcast ───────────────────────────────────────────────────────

    private fun startStatsJob() {
        statsJob = serviceScope.launch {
            while (isRunning) {
                delay(STATS_INTERVAL)
                sendBroadcast(
                    Intent(ACTION_STATS_UPDATE)
                        .putExtra(EXTRA_BLOCKED_COUNT, blockedCount.get())
                        .setPackage(packageName)
                )
            }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun ensureNotificationChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "System Security", NotificationManager.IMPORTANCE_MIN
        ).apply { description = "Security monitoring running"; setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Security Active")
            .setContentText("Security monitoring running")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .build()
    }
}
