package com.sgyt.guardianblock.ui.lockscreen

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sgyt.guardianblock.data.DnsQueryStore
import com.sgyt.guardianblock.domain.model.DnsQuery
import com.sgyt.guardianblock.domain.repository.BlockRepository
import com.sgyt.guardianblock.service.PrivateDnsService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest
import javax.inject.Inject

@HiltViewModel
class LockScreenViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: BlockRepository,
    private val dnsQueryStore: DnsQueryStore,
) : ViewModel() {

    private val _state = MutableStateFlow(LockUiState())
    val state: StateFlow<LockUiState> = _state.asStateFlow()

    private var lockoutJob: Job? = null

    init {
        // Load existing PIN hash
        viewModelScope.launch {
            val hash = repository.getPinHash()
            _state.value = _state.value.copy(pinHash = hash)
        }

        // Collect DNS queries
        viewModelScope.launch {
            dnsQueryStore.queries.collect { list ->
                _state.value = _state.value.copy(queries = list)
            }
        }

        // Register broadcast receiver for live DNS queries
        registerDnsReceiver()
    }

    private var dnsReceiver: BroadcastReceiver? = null

    private fun registerDnsReceiver() {
        // Prevent double registration
        if (dnsReceiver != null) return

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action != PrivateDnsService.ACTION_DNS_QUERY) return
                if (!_state.value.liveQueryEnabled) return
                val domain = intent.getStringExtra(PrivateDnsService.EXTRA_DOMAIN) ?: return
                val blocked = intent.getBooleanExtra(PrivateDnsService.EXTRA_BLOCKED, false)
                viewModelScope.launch {
                    dnsQueryStore.add(domain, blocked)
                }
            }
        }
        try {
            // Use RECEIVER_EXPORTED for broadcasts from our own service
            androidx.core.content.ContextCompat.registerReceiver(
                context, receiver,
                IntentFilter(PrivateDnsService.ACTION_DNS_QUERY),
                androidx.core.content.ContextCompat.RECEIVER_EXPORTED
            )
            dnsReceiver = receiver
        } catch (_: Exception) { }
    }

    // ── Digit input ──────────────────────────────────────────

    fun onDigitEntered(digit: Int) {
        val s = _state.value
        if (s.lockState == LockState.LockedOut) return
        if (s.digitBuffer.size >= s.maxDigits) return
        val newBuffer = s.digitBuffer + digit
        _state.value = s.copy(
            digitBuffer  = newBuffer,
            lockState    = if (newBuffer.size < s.maxDigits) LockState.Inputting else s.lockState,
            errorMessage = null
        )
        // Auto-submit when buffer is full
        if (newBuffer.size == s.maxDigits) {
            processPinCheck(newBuffer.map(Int::toString).joinToString(""))
        }
    }

    fun onBackspace() {
        val s = _state.value
        if (s.digitBuffer.isEmpty()) return
        val newBuffer = s.digitBuffer.dropLast(1)
        _state.value = s.copy(
            digitBuffer  = newBuffer,
            lockState    = if (newBuffer.isEmpty()) LockState.Idle else LockState.Inputting,
            errorMessage = null
        )
    }

    // ── Pattern input ────────────────────────────────────────

    fun onPatternNodeSelected(nodeIndex: Int) {
        val s = _state.value
        if (s.lockState == LockState.LockedOut) return
        if (nodeIndex in s.patternNodes) return
        val newNodes = s.patternNodes + nodeIndex
        _state.value = s.copy(patternNodes = newNodes, lockState = LockState.Inputting)
        if (newNodes.size >= 4) {
            processPatternCheck(newNodes)
        }
    }

    fun onCancelPattern() {
        _state.value = _state.value.copy(
            patternNodes = emptyList(),
            lockState    = LockState.Idle
        )
    }

    // ── PIN / Pattern validation ─────────────────────────────

    private fun processPinCheck(pin: String) {
        val hash = _state.value.pinHash
        viewModelScope.launch {
            if (hash.isEmpty()) {
                // First time — set the PIN
                repository.savePinHash(sha256(pin))
                _state.value = _state.value.copy(
                    isAuthenticated = true,
                    lockState       = LockState.Success,
                    digitBuffer     = emptyList()
                )
            } else {
                if (sha256(pin) == hash) {
                    _state.value = _state.value.copy(
                        isAuthenticated = true,
                        lockState       = LockState.Success,
                        digitBuffer     = emptyList()
                    )
                } else {
                    onAuthFailure("Wrong code")
                }
            }
        }
    }

    private fun processPatternCheck(nodes: List<Int>) {
        val hash = _state.value.pinHash
        viewModelScope.launch {
            // Convert pattern to a hashable string
            val patternStr = nodes.joinToString("-")
            if (hash.isEmpty()) {
                repository.savePinHash(sha256(patternStr))
                _state.value = _state.value.copy(
                    isAuthenticated = true,
                    lockState       = LockState.Success,
                    patternNodes    = emptyList()
                )
            } else {
                if (sha256(patternStr) == hash) {
                    _state.value = _state.value.copy(
                        isAuthenticated = true,
                        lockState       = LockState.Success,
                        patternNodes    = emptyList()
                    )
                } else {
                    onAuthFailure("Wrong pattern")
                }
            }
        }
    }

    // ── Auth failure with lockout ────────────────────────────

    private fun onAuthFailure(error: String) {
        val s = _state.value
        val newCount = s.failureCount + 1
        if (newCount >= LockTokens.MAX_FAILURES) {
            _state.value = s.copy(
                lockState      = LockState.LockedOut,
                failureCount   = newCount,
                lockoutEndTime = System.currentTimeMillis() + LockTokens.LOCKOUT_MS,
                errorMessage   = error,
                digitBuffer    = emptyList(),
                patternNodes   = emptyList()
            )
            startLockoutTimer()
        } else {
            _state.value = s.copy(
                lockState      = LockState.Error,
                failureCount   = newCount,
                errorMessage   = error,
                digitBuffer    = emptyList(),
                patternNodes   = emptyList()
            )
            // Auto-dismiss error after 1.2s
            viewModelScope.launch {
                delay(LockAnimations.ErrorShakeDamp.toLong())
                _state.value = _state.value.copy(errorMessage = null, lockState = LockState.Idle)
            }
        }
    }

    // ── Lockout timer ────────────────────────────────────────

    private fun startLockoutTimer() {
        lockoutJob?.cancel()
        lockoutJob = viewModelScope.launch {
            delay(LockTokens.LOCKOUT_MS)
            _state.value = _state.value.copy(
                lockState       = LockState.Idle,
                failureCount    = 0,
                lockoutEndTime  = null,
                errorMessage    = null
            )
        }
    }

    // ── Method change ────────────────────────────────────────

    fun onMethodChanged(method: LockMethod) {
        val s = _state.value
        if (s.lockState == LockState.LockedOut) return
        _state.value = s.copy(
            method       = method,
            digitBuffer  = emptyList(),
            patternNodes = emptyList(),
            lockState    = LockState.Idle,
            errorMessage = null
        )
    }

    fun onLiveQueryToggled() {
        val s = _state.value
        _state.value = s.copy(liveQueryEnabled = !s.liveQueryEnabled)
    }

    fun onClearQueries() {
        viewModelScope.launch {
            dnsQueryStore.clearAll()
        }
    }

    // ── SHA-256 ──────────────────────────────────────────────

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    override fun onCleared() {
        super.onCleared()
        lockoutJob?.cancel()
        // Unregister broadcast receiver to prevent leaks
        try {
            dnsReceiver?.let { receiver ->
                context.unregisterReceiver(receiver)
            }
        } catch (_: Exception) {}
    }
}
