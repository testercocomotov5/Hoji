package com.sgyt.guardianblock.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [DnsQueryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dnsQueryDao(): DnsQueryDao
}
