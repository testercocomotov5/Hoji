package com.sgyt.guardianblock.ui.dashboard

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sgyt.guardianblock.ui.theme.themeColors

// BUG-7 FIX: All hardcoded Color.White / Color(0xFF1A1A1A) replaced with
// themeColors() which returns correct values for both light and dark themes.

@Composable
fun DashboardScreen(
    onNavigateToSettings: () -> Unit,
    onNavigateToQueries: () -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val state  by viewModel.state.collectAsStateWithLifecycle()
    val tc      = themeColors()

    val vpnPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) viewModel.onVpnPermissionGranted()
        else viewModel.onVpnPermissionDenied()
    }

    LaunchedEffect(state.needsVpnPermission) {
        if (state.needsVpnPermission) {
            viewModel.requestVpnPermissionIntent()?.let {
                vpnPermLauncher.launch(it)
                viewModel.clearVpnPermissionFlag()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tc.background)          // ← theme-aware
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(48.dp))

        // Header
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "GuardianBlock",
                    style      = MaterialTheme.typography.headlineMedium,
                    color      = tc.textPrimary,           // ← theme-aware
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    "Private DNS Protection",
                    style = MaterialTheme.typography.bodyMedium,
                    color = tc.textDisabled
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick  = onNavigateToQueries,
                    modifier = Modifier
                        .size(44.dp)
                        .background(tc.surface, RoundedCornerShape(14.dp))
                ) {
                    Icon(Icons.Rounded.Visibility, "DNS Queries", tint = tc.accent)
                }
                IconButton(
                    onClick  = onNavigateToSettings,
                    modifier = Modifier
                        .size(44.dp)
                        .background(tc.surface, RoundedCornerShape(14.dp))
                ) {
                    Icon(Icons.Rounded.Settings, "Settings", tint = tc.textPrimary)
                }
            }
        }

        DnsStatusCard(
            isEnabled    = state.config.isDnsEnabled,
            permRequired = state.needsVpnPermission,
            onToggle     = { viewModel.toggleDns { vpnPermLauncher.launch(it) } },
            onGrant      = { viewModel.requestVpnPermissionIntent()?.let { vpnPermLauncher.launch(it) } }
        )

        AnimatedVisibility(
            visible = state.config.isDnsEnabled,
            enter   = fadeIn(tween(350)) + expandVertically(
                spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)
            ),
            exit    = fadeOut(tween(200)) + shrinkVertically(tween(200))
        ) {
            StatsRow(
                keywordsActive = state.config.keywords.count { it.value },
                blockedQueries = state.blockedQueries
            )
        }

        KeywordsCard(keywords = state.config.keywords)
        InfoCard()
        Spacer(Modifier.height(28.dp))
    }
}

// ── Status card ───────────────────────────────────────────────────────────────

@Composable
private fun DnsStatusCard(
    isEnabled: Boolean,
    permRequired: Boolean,
    onToggle: () -> Unit,
    onGrant: () -> Unit
) {
    val tc = themeColors()
    val borderColor by animateColorAsState(
        if (isEnabled) Color(0xFF00843D).copy(0.3f) else tc.border, tween(600), label = "b")
    val bgTop by animateColorAsState(
        if (isEnabled) Color(0xFF00843D).copy(0.08f) else tc.surface, tween(600), label = "t")
    val bgBot by animateColorAsState(
        if (isEnabled) Color(0xFF00843D).copy(0.13f) else tc.surfaceVariant, tween(600), label = "bt")
    val accentColor by animateColorAsState(
        if (isEnabled) Color(0xFF00843D) else tc.textDisabled, tween(400), label = "a")

    val inf = rememberInfiniteTransition(label = "shield")
    val pulseAlpha by inf.animateFloat(
        if (isEnabled) 0.4f else 0f, 0f,
        infiniteRepeatable(tween(2200, easing = EaseInOutSine), RepeatMode.Restart), "pa")
    val pulseScale by inf.animateFloat(
        1f, if (isEnabled) 1.45f else 1f,
        infiniteRepeatable(tween(2200, easing = EaseInOutCubic), RepeatMode.Restart), "ps")
    val heartbeatAlpha by inf.animateFloat(
        if (isEnabled) 0.25f else 0f, 0f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Restart), "hb")
    val shieldRotation by inf.animateFloat(
        -1f, if (isEnabled) 1f else -1f,
        infiniteRepeatable(tween(3000, easing = EaseInOutSine), RepeatMode.Reverse), "sr")

    Card(
        Modifier.fillMaxWidth().border(1.dp, borderColor, RoundedCornerShape(24.dp)),
        shape     = RoundedCornerShape(24.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(bgTop, bgBot)))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.Center) {
                            Box(Modifier.size(66.dp).graphicsLayer {
                                alpha  = pulseAlpha; scaleX = pulseScale; scaleY = pulseScale
                            }.background(Color(0xFF00843D).copy(0.12f), CircleShape))
                            Box(Modifier.size(58.dp).graphicsLayer { alpha = heartbeatAlpha }
                                .background(Color(0xFF00843D).copy(0.2f), CircleShape))
                            Box(
                                Modifier.size(54.dp)
                                    .background(if (isEnabled) Color(0xFF00843D).copy(0.15f) else tc.surface, CircleShape)
                                    .border(1.dp, accentColor.copy(0.35f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    if (isEnabled) Icons.Rounded.Shield else Icons.Rounded.Security,
                                    null, tint = accentColor,
                                    modifier = Modifier.size(28.dp).graphicsLayer { rotationZ = shieldRotation }
                                )
                            }
                        }
                        Column {
                            Text(
                                when {
                                    isEnabled    -> "DNS Protection ON"
                                    permRequired -> "Permission Required"
                                    else         -> "Protection OFF"
                                },
                                style      = MaterialTheme.typography.titleLarge,
                                color      = tc.textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                when {
                                    isEnabled    -> "Filtering via system DNS"
                                    permRequired -> "Tap below to grant access"
                                    else         -> "Tap toggle to activate"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isEnabled) Color(0xFF00843D).copy(0.85f) else tc.textDisabled
                            )
                        }
                    }
                    Switch(
                        checked         = isEnabled,
                        onCheckedChange = { onToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor    = tc.textPrimary,
                            checkedTrackColor    = Color(0xFF00843D),
                            checkedBorderColor   = Color(0xFF00843D),
                            uncheckedThumbColor  = tc.textDisabled,
                            uncheckedBorderColor = tc.border
                        )
                    )
                }

                AnimatedContent(
                    targetState  = when { isEnabled -> "active"; permRequired -> "perm"; else -> "off" },
                    transitionSpec = { fadeIn(tween(280)) togetherWith fadeOut(tween(180)) },
                    label = "pill"
                ) { s ->
                    when (s) {
                        "active" -> StatusPill(Icons.Rounded.CheckCircle,
                            "All DNS queries filtered locally — no latency added", Color(0xFF00843D))
                        "perm"   -> Button(
                            onClick  = onGrant,
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                            shape    = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Rounded.Lock, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Grant Permission (one-time)", fontWeight = FontWeight.SemiBold)
                        }
                        else     -> StatusPill(Icons.Rounded.Info,
                            "Gambling sites are currently reachable", tc.textDisabled)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusPill(icon: ImageVector, label: String, color: Color) {
    val tc = themeColors()
    Row(
        Modifier.fillMaxWidth()
            .background(color.copy(0.08f), RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        Arrangement.spacedBy(8.dp), Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(16.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = color)
    }
}

// ── Stats row ─────────────────────────────────────────────────────────────────

@Composable
private fun StatsRow(keywordsActive: Int, blockedQueries: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatChip(Modifier.weight(1f), Icons.Rounded.Block,
            "$keywordsActive", "Active rules", Color(0xFFE30613), animated = false)
        StatChip(Modifier.weight(1f), Icons.Rounded.Shield,
            "$blockedQueries", "Blocked", Color(0xFF00843D), animated = true)
        StatChip(Modifier.weight(1f), Icons.Rounded.Autorenew,
            "24/7", "Always on", Color(0xFF7C4DFF), animated = false)
    }
}

@Composable
private fun StatChip(
    modifier: Modifier, icon: ImageVector, value: String,
    label: String, color: Color, animated: Boolean
) {
    val tc = themeColors()
    Column(
        modifier
            .background(tc.surface, RoundedCornerShape(16.dp))
            .border(1.dp, color.copy(0.22f), RoundedCornerShape(16.dp))
            .padding(vertical = 14.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        if (animated) {
            AnimatedContent(
                targetState  = value,
                transitionSpec = {
                    (slideInVertically { h -> h } + fadeIn(tween(220))) togetherWith
                    (slideOutVertically { h -> -h } + fadeOut(tween(160))) using
                    SizeTransform(clip = false)
                },
                label = "counter"
            ) { v ->
                Text(v, style = MaterialTheme.typography.titleMedium,
                    color = tc.textPrimary, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center)
            }
        } else {
            Text(value, style = MaterialTheme.typography.titleMedium,
                color = tc.textPrimary, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center)
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = tc.textDisabled)
    }
}

// ── Keywords card ─────────────────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KeywordsCard(keywords: Map<String, Boolean>) {
    val tc           = themeColors()
    val enabledCount = keywords.count { it.value }
    GlassCard {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                Arrangement.SpaceBetween,
                Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    SmallIconBox(Icons.Rounded.Block, Color(0xFFE30613))
                    Text("Blocked Keywords", style = MaterialTheme.typography.titleMedium,
                        color = tc.textPrimary, fontWeight = FontWeight.SemiBold)
                }
                Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE30613).copy(0.15f)) {
                    Text("$enabledCount/${keywords.size}",
                        Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFE30613), fontWeight = FontWeight.Bold)
                }
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement   = Arrangement.spacedBy(8.dp)
            ) {
                keywords.forEach { (kw, enabled) -> KeywordChip(kw, enabled) }
            }
        }
    }
}

@Composable
private fun KeywordChip(keyword: String, enabled: Boolean) {
    val tc     = themeColors()
    val bg     = if (enabled) Color(0xFFE30613).copy(0.18f) else Color.Transparent
    val border = if (enabled) Color(0xFFE30613).copy(0.5f)  else tc.border
    val text   = if (enabled) Color(0xFFE30613)              else tc.textDisabled
    Row(
        modifier = Modifier.background(bg, RoundedCornerShape(10.dp))
            .border(1.dp, border, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (enabled) Box(Modifier.size(5.dp).background(Color(0xFF00843D), CircleShape))
        Text(keyword, style = MaterialTheme.typography.labelMedium, color = text)
    }
}

// ── Info card ─────────────────────────────────────────────────────────────────

@Composable
private fun InfoCard() {
    val tc = themeColors()
    GlassCard {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                SmallIconBox(Icons.Rounded.Info, Color(0xFFE30613))
                Text("How it works", style = MaterialTheme.typography.titleMedium,
                    color = tc.textPrimary, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "GuardianBlock runs a local VPN that intercepts only DNS queries (port 53). " +
                "Allowed domains are forwarded to your network's own DNS servers — the exact " +
                "same path the device would use without this app, so there is zero added latency. " +
                "Gambling domains matching a keyword receive NXDOMAIN instantly on-device.",
                style = MaterialTheme.typography.bodyMedium,
                color = tc.textSecondary, lineHeight = 20.sp
            )
            HorizontalDivider(color = tc.border, thickness = 0.5.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Warning, null, tint = Color(0xFFFFB300),
                    modifier = Modifier.size(15.dp))
                Text("Uses your network's own DNS servers — no third-party DNS is involved.",
                    style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFB300))
            }
        }
    }
}

// ── Shared helpers ────────────────────────────────────────────────────────────

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    val tc = themeColors()
    Box(
        Modifier.fillMaxWidth()
            .background(tc.surface, RoundedCornerShape(20.dp))
            .border(1.dp, tc.border, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) { Column(content = content) }
}

@Composable
private fun SmallIconBox(icon: ImageVector, color: Color) {
    Box(
        Modifier.size(32.dp)
            .background(color.copy(0.10f), RoundedCornerShape(9.dp))
            .border(1.dp, color.copy(0.2f), RoundedCornerShape(9.dp)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = color, modifier = Modifier.size(17.dp)) }
}
