package com.sgyt.guardianblock.service

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * DnsInterceptor v9 — fully local DNS forwarding, all known bugs fixed
 *
 * Bug fixes in v9:
 *
 * [BUG-E FIX] upstreamResponse size is now checked before accessing byte[2] for the TC
 * bit. A malformed response shorter than 3 bytes would previously throw
 * ArrayIndexOutOfBoundsException and crash the processing coroutine.
 *
 * [BUG-F FIX] RFC 7766 TCP retry now uses the SAME server that returned TC=1, not
 * servers.first(). Previously, if the second DNS server responded truncated,
 * the TCP retry was incorrectly sent to the first server.
 *
 * Retained from v8:
 * [BUG-B] Physical-network DNS via SystemDnsProvider (infinite loop fix)
 * [BUG-C] Unparseable queries forwarded instead of dropped
 * [BUG-D] QR bit verified — responses returned unchanged
 * [BUG-1] UDP socket protected before send()
 * [BUG-2] Per-server 2 s timeout
 * [BUG-3] SERVFAIL on total failure
 * [BUG-4] process() is stateless — concurrent-safe
 *
 * [BUG-G FIX] onQuery callback is now called for every DNS query to notify UI
 */
class DnsInterceptor(
    private val systemDns: SystemDnsProvider,
    private val protectUdpSocket: (DatagramSocket) -> Boolean,
    private val protectTcpSocket: (java.net.Socket) -> Boolean,
    private val onDomainBlocked: () -> Unit = {},
    private val onQuery: (String, Boolean) -> Unit = { _, _ -> }
) {

    companion object {
        private const val DNS_PORT = 53
        private const val SOCKET_TIMEOUT_MS = 2_000
        private const val MAX_LABEL_LEN = 63
        private const val MAX_PTR_DEPTH = 5
    }

    // -------------------------------------------------------------------------
    // Entry point — stateless; safe to call concurrently from parallel coroutines
    // -------------------------------------------------------------------------

    fun process(rawPacket: ByteArray, enabledKeywords: List<String>): ByteArray? {
        if (rawPacket.size < 28) return null

        val ipHeaderLen = (rawPacket[0].toInt() and 0x0F) * 4
        if (ipHeaderLen < 20 || ipHeaderLen > rawPacket.size) return null

        if (rawPacket[9].toInt() and 0xFF != 17) return null // UDP only

        val dstPort = ((rawPacket[ipHeaderLen + 2].toInt() and 0xFF) shl 8) or
                (rawPacket[ipHeaderLen + 3].toInt() and 0xFF)
        if (dstPort != DNS_PORT) return null

        val dnsOffset = ipHeaderLen + 8
        if (rawPacket.size <= dnsOffset + 12) return null

        val dnsPayload = rawPacket.copyOfRange(dnsOffset, rawPacket.size)

        // BUG-D: check QR bit — QR=1 means it's already a response; return unchanged.
        if (dnsPayload[2].toInt() and 0x80 != 0) {
            return buildUdpIpPacket(rawPacket, ipHeaderLen, dnsPayload)
        }

        // BUG-C: forward unparseable queries instead of dropping them.
        val domain = parseDnsDomain(dnsPayload)
            ?: return forwardDns(rawPacket, ipHeaderLen, dnsPayload)
                ?: buildServfailResponse(rawPacket, ipHeaderLen, dnsPayload)

        val blocked = enabledKeywords.any { kw -> domain.contains(kw, ignoreCase = true) }

        // BUG-G FIX: Notify about the query for UI updates
        onQuery(domain, blocked)

        return if (blocked) {
            onDomainBlocked()
            buildNxdomainResponse(rawPacket, ipHeaderLen, dnsPayload)
        } else {
            forwardDns(rawPacket, ipHeaderLen, dnsPayload)
                ?: buildServfailResponse(rawPacket, ipHeaderLen, dnsPayload)
        }
    }

    // -------------------------------------------------------------------------
    // Forward DNS using device's own DNS servers (from SystemDnsProvider)
    // -------------------------------------------------------------------------

    private fun forwardDns(
        originalPacket: ByteArray,
        ipHeaderLen: Int,
        dnsQuery: ByteArray
    ): ByteArray? {
        val servers = systemDns.getServers()
        if (servers.isEmpty()) return null

        // BUG-F FIX: track which server responded so TCP retry goes to the SAME server.
        // Previously the code always used servers.first() for TCP retry, which is wrong
        // when a later server in the list is the one that returned TC=1.
        var respondingServer: InetAddress? = null
        val upstreamResponse = servers.firstNotNullOfOrNull { server ->
            tryForwardUdp(dnsQuery, server)?.also { respondingServer = server }
        } ?: return null

        // BUG-E FIX: guard against a malformed upstream response shorter than the DNS header.
        // Without this, the TC bit check below throws ArrayIndexOutOfBoundsException.
        if (upstreamResponse.size < 3) {
            return buildUdpIpPacket(originalPacket, ipHeaderLen, upstreamResponse)
        }

        // RFC 7766: if upstream sets TC=1 (truncated), retry over TCP to the SAME server.
        val tc = (upstreamResponse[2].toInt() and 0x02) != 0
        val finalResponse = if (tc) {
            forwardTcp(dnsQuery, respondingServer!!) ?: upstreamResponse
        } else {
            upstreamResponse
        }

        return buildUdpIpPacket(originalPacket, ipHeaderLen, finalResponse)
    }

    private fun tryForwardUdp(dnsQuery: ByteArray, server: InetAddress): ByteArray? {
        return try {
            val socket = DatagramSocket()
            if (!protectUdpSocket(socket)) { socket.close(); return null }
            socket.soTimeout = SOCKET_TIMEOUT_MS
            socket.send(DatagramPacket(dnsQuery, dnsQuery.size, server, DNS_PORT))
            val buf = ByteArray(4096)
            val pkt = DatagramPacket(buf, buf.size)
            socket.receive(pkt)
            socket.close()
            buf.copyOfRange(0, pkt.length)
        } catch (_: Exception) { null }
    }

    /**
     * RFC 7766 TCP DNS.
     * Socket is protected BEFORE connect() — prevents it re-entering the VPN tunnel.
     */
    private fun forwardTcp(dnsQuery: ByteArray, server: InetAddress): ByteArray? {
        return try {
            val tcpSock = java.net.Socket()
            if (!protectTcpSocket(tcpSock)) { tcpSock.close(); return null }
            tcpSock.connect(java.net.InetSocketAddress(server, DNS_PORT), SOCKET_TIMEOUT_MS)
            tcpSock.soTimeout = SOCKET_TIMEOUT_MS
            val out = tcpSock.getOutputStream()
            val inp = tcpSock.getInputStream()
            out.write((dnsQuery.size shr 8) and 0xFF)
            out.write(dnsQuery.size and 0xFF)
            out.write(dnsQuery)
            out.flush()
            val lenHi = inp.read(); val lenLo = inp.read()
            if (lenHi < 0 || lenLo < 0) { tcpSock.close(); return null }
            val msgLen = (lenHi shl 8) or lenLo
            val response = ByteArray(msgLen)
            var read = 0
            while (read < msgLen) {
                val n = inp.read(response, read, msgLen - read)
                if (n < 0) break
                read += n
            }
            tcpSock.close()
            if (read == msgLen) response else null
        } catch (_: Exception) { null }
    }

    // -------------------------------------------------------------------------
    // DNS domain parser (RFC 1035 §3.1)
    // -------------------------------------------------------------------------

    private fun parseDnsDomain(dns: ByteArray): String? {
        if (dns.size < 13) return null
        val sb = StringBuilder()
        var pos = 12
        var ptrDepth = 0
        var totalLen = 0
        return try {
            while (pos < dns.size) {
                val lenByte = dns[pos].toInt() and 0xFF
                when {
                    lenByte == 0 -> break
                    (lenByte and 0xC0) == 0xC0 -> { ptrDepth++; if (ptrDepth > MAX_PTR_DEPTH) return null; break }
                    lenByte > MAX_LABEL_LEN -> return null
                    else -> {
                        pos++
                        if (pos + lenByte > dns.size) return null
                        totalLen += lenByte + 1
                        if (totalLen > 255) return null
                        if (sb.isNotEmpty()) sb.append('.')
                        sb.append(String(dns, pos, lenByte, Charsets.UTF_8))
                        pos += lenByte
                    }
                }
            }
            if (sb.isNotEmpty()) sb.toString() else null
        } catch (_: Exception) { null }
    }

    // -------------------------------------------------------------------------
    // NXDOMAIN (RCODE=3) — blocked domain
    // -------------------------------------------------------------------------

    private fun buildNxdomainResponse(
        originalPacket: ByteArray,
        ipHeaderLen: Int,
        dnsQuery: ByteArray
    ): ByteArray {
        val resp = dnsQuery.copyOf()
        val flags = ((resp[2].toInt() and 0xFF) shl 8) or (resp[3].toInt() and 0xFF)
        val newFlags = (flags or 0x8080) and 0xFFF3 or 0x0003 // QR=1 RA=1 RCODE=3
        resp[2] = (newFlags shr 8).toByte(); resp[3] = (newFlags and 0xFF).toByte()
        resp[6] = 0; resp[7] = 0; resp[8] = 0; resp[9] = 0; resp[10] = 0; resp[11] = 0
        return buildUdpIpPacket(originalPacket, ipHeaderLen, resp)
    }

    // -------------------------------------------------------------------------
    // SERVFAIL (RCODE=2) — all upstreams failed; immediate error for client
    // -------------------------------------------------------------------------

    private fun buildServfailResponse(
        originalPacket: ByteArray,
        ipHeaderLen: Int,
        dnsQuery: ByteArray
    ): ByteArray {
        val resp = dnsQuery.copyOf()
        val flags = ((resp[2].toInt() and 0xFF) shl 8) or (resp[3].toInt() and 0xFF)
        val newFlags = (flags or 0x8080) and 0xFFF0 or 0x0002 // QR=1 RA=1 RCODE=2
        resp[2] = (newFlags shr 8).toByte(); resp[3] = (newFlags and 0xFF).toByte()
        resp[6] = 0; resp[7] = 0; resp[8] = 0; resp[9] = 0; resp[10] = 0; resp[11] = 0
        return buildUdpIpPacket(originalPacket, ipHeaderLen, resp)
    }

    // -------------------------------------------------------------------------
    // IPv4 / UDP packet builder (src ↔ dst swapped for response)
    // -------------------------------------------------------------------------

    private fun buildUdpIpPacket(
        orig: ByteArray, ipHeaderLen: Int, dnsPayload: ByteArray
    ): ByteArray {
        val origSrcIp = orig.copyOfRange(12, 16)
        val origDstIp = orig.copyOfRange(16, 20)
        val origSrcPort = byteArrayOf(orig[ipHeaderLen], orig[ipHeaderLen + 1])
        val origDstPort = byteArrayOf(orig[ipHeaderLen + 2], orig[ipHeaderLen + 3])

        val udpLen = 8 + dnsPayload.size
        val totalLen = ipHeaderLen + udpLen
        val pkt = ByteArray(totalLen)

        pkt[0] = ((4 shl 4) or (ipHeaderLen / 4)).toByte()
        pkt[1] = 0
        pkt[2] = (totalLen ushr 8).toByte(); pkt[3] = totalLen.toByte()
        pkt[4] = orig[4]; pkt[5] = orig[5]
        pkt[6] = 0x40; pkt[7] = 0
        pkt[8] = 64; pkt[9] = 17
        pkt[10] = 0; pkt[11] = 0
        origDstIp.copyInto(pkt, 12)
        origSrcIp.copyInto(pkt, 16)

        val csum = ipChecksum(pkt, ipHeaderLen)
        pkt[10] = (csum ushr 8).toByte(); pkt[11] = csum.toByte()

        origDstPort.copyInto(pkt, ipHeaderLen)
        origSrcPort.copyInto(pkt, ipHeaderLen + 2)
        pkt[ipHeaderLen + 4] = (udpLen ushr 8).toByte()
        pkt[ipHeaderLen + 5] = udpLen.toByte()
        pkt[ipHeaderLen + 6] = 0; pkt[ipHeaderLen + 7] = 0

        dnsPayload.copyInto(pkt, ipHeaderLen + 8)
        return pkt
    }

    private fun ipChecksum(data: ByteArray, len: Int): Int {
        var sum = 0; var i = 0
        while (i < len - 1) {
            sum += ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (len % 2 != 0) sum += (data[len - 1].toInt() and 0xFF) shl 8
        while (sum ushr 16 != 0) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv() and 0xFFFF
    }
}
