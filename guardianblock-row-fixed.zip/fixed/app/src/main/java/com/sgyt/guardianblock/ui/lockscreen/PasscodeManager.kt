package com.sgyt.guardianblock.ui.lockscreen

import android.content.Context
import android.content.SharedPreferences

class PasscodeManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "rotary_lockscreen_prefs"
        private const val KEY_PASSCODE = "passcode"
    }

    var correctPasscode: String?
        get() = prefs.getString(KEY_PASSCODE, null)
        set(value) {
            if (value != null) {
                prefs.edit().putString(KEY_PASSCODE, value).apply()
            } else {
                prefs.edit().remove(KEY_PASSCODE).apply()
            }
        }

    fun isPasscodeCorrect(entered: String): Boolean {
        return entered == correctPasscode
    }

    fun hasPasscode(): Boolean {
        return correctPasscode != null && correctPasscode!!.isNotEmpty()
    }

    fun clearPasscode() {
        prefs.edit().remove(KEY_PASSCODE).apply()
    }
}