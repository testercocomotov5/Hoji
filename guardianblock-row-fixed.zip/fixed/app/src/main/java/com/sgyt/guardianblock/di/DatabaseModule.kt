package com.sgyt.guardianblock.di

import android.content.Context
import androidx.room.Room
import com.sgyt.guardianblock.data.local.AppDatabase
import com.sgyt.guardianblock.data.local.DnsQueryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "guardianblock_db"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideDnsQueryDao(database: AppDatabase): DnsQueryDao {
        return database.dnsQueryDao()
    }
}
