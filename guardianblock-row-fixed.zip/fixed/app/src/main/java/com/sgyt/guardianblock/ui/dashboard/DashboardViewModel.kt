package com.sgyt.guardianblock.ui.dashboard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sgyt.guardianblock.domain.model.BlockConfig
import com.sgyt.guardianblock.domain.usecase.GetBlockConfigUseCase
import com.sgyt.guardianblock.domain.usecase.SaveBlockConfigUseCase
import com.sgyt.guardianblock.receiver.DnsWatchdogReceiver
import com.sgyt.guardianblock.service.PrivateDnsService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val config: BlockConfig         = BlockConfig(),
    val isLoading: Boolean          = true,
    val needsVpnPermission: Boolean = false,
    val blockedQueries: Int         = 0
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val getConfig: GetBlockConfigUseCase,
    private val saveConfig: SaveBlockConfigUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    // ── Stats broadcast receiver ───────────────────────────────────────────

    private val statsReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == PrivateDnsService.ACTION_STATS_UPDATE) {
                val count = intent.getIntExtra(PrivateDnsService.EXTRA_BLOCKED_COUNT, 0)
                _state.value = _state.value.copy(blockedQueries = count)
            }
        }
    }

    init {
        ContextCompat.registerReceiver(
            context,
            statsReceiver,
            IntentFilter(PrivateDnsService.ACTION_STATS_UPDATE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        viewModelScope.launch {
            getConfig().collect { cfg ->
                val wasLoading = _state.value.isLoading
                _state.value = _state.value.copy(config = cfg, isLoading = false)

                if (wasLoading) {
                    val permIntent = VpnService.prepare(context)
                    if (permIntent != null) {
                        // BUG-I FIX: Do NOT save isDnsEnabled=true here.
                        //
                        // The old code called saveConfig(cfg.copy(isDnsEnabled = true)) at
                        // this point, which had two problems:
                        //   1. It overwrote the user's stored isDnsEnabled preference with true
                        //      regardless of what they had previously chosen.
                        //   2. It marked DNS as enabled before the user had actually granted
                        //      VPN permission — so if they denied the permission dialog, the
                        //      DataStore was left with isDnsEnabled = true while the VPN was
                        //      not running.
                        //
                        // Correct behaviour: just show the permission UI.  isDnsEnabled is
                        // saved to true only inside onVpnPermissionGranted(), i.e., AFTER the
                        // user confirms.  If they deny, onVpnPermissionDenied() saves false.
                        _state.value = _state.value.copy(needsVpnPermission = true)
                    } else if (cfg.isDnsEnabled) {
                        startDnsInternal()
                    }
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try { context.unregisterReceiver(statsReceiver) } catch (_: Exception) {}
    }

    // ── Public API ─────────────────────────────────────────────────────────

    fun requestVpnPermissionIntent(): Intent? = VpnService.prepare(context)

    fun toggleDns(requestPermission: (Intent) -> Unit) {
        if (_state.value.config.isDnsEnabled) {
            stopDns()
        } else {
            val vpnIntent = VpnService.prepare(context)
            if (vpnIntent != null) requestPermission(vpnIntent) else startDns()
        }
    }

    fun onVpnPermissionGranted() {
        _state.value = _state.value.copy(needsVpnPermission = false)
        startDns()
    }

    fun onVpnPermissionDenied() {
        viewModelScope.launch {
            saveConfig(_state.value.config.copy(isDnsEnabled = false))
        }
    }

    fun clearVpnPermissionFlag() {
        _state.value = _state.value.copy(needsVpnPermission = false)
    }

    // ── Internal ───────────────────────────────────────────────────────────

    private fun startDns() {
        viewModelScope.launch {
            _state.value = _state.value.copy(blockedQueries = 0)
            saveConfig(_state.value.config.copy(isDnsEnabled = true))
            startDnsInternal()
        }
    }

    private fun startDnsInternal() {
        try {
            context.startForegroundService(
                Intent(context, PrivateDnsService::class.java)
                    .apply { action = PrivateDnsService.ACTION_START }
            )
            DnsWatchdogReceiver.schedule(context)
        } catch (_: Exception) {
            viewModelScope.launch {
                saveConfig(_state.value.config.copy(isDnsEnabled = false))
            }
        }
    }

    private fun stopDns() {
        viewModelScope.launch {
            saveConfig(_state.value.config.copy(isDnsEnabled = false))
            _state.value = _state.value.copy(blockedQueries = 0)
            DnsWatchdogReceiver.cancel(context)
            context.startService(
                Intent(context, PrivateDnsService::class.java)
                    .apply { action = PrivateDnsService.ACTION_STOP }
            )
        }
    }
}
