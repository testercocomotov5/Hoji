package com.sgyt.guardianblock.ui.pin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sgyt.guardianblock.domain.repository.BlockRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest
import javax.inject.Inject

data class PinUiState(
    val pinHash       : String  = "",
    val enteredPin    : String  = "",
    val isAuthenticated: Boolean = false,
    val showError     : Boolean = false,
    val isLoading     : Boolean = true
)

@HiltViewModel
class PinViewModel @Inject constructor(
    private val repository: BlockRepository
) : ViewModel() {

    private val _state = MutableStateFlow(PinUiState())
    val state: StateFlow<PinUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val hash = repository.getPinHash()
            _state.value = _state.value.copy(pinHash = hash, isLoading = false)
        }
    }

    fun onDigitEntered(digit: String) {
        val current = _state.value.enteredPin
        if (current.length >= 4) return
        val updated = current + digit
        _state.value = _state.value.copy(enteredPin = updated, showError = false)
        if (updated.length == 4) processPin(updated)
    }

    fun onBackspace() {
        val current = _state.value.enteredPin
        if (current.isNotEmpty()) {
            _state.value = _state.value.copy(enteredPin = current.dropLast(1), showError = false)
        }
    }

    private fun processPin(pin: String) {
        val hash = _state.value.pinHash
        if (hash.isEmpty()) {
            // No PIN set yet — set it now
            viewModelScope.launch {
                repository.savePinHash(sha256(pin))
                _state.value = _state.value.copy(isAuthenticated = true)
            }
        } else {
            if (sha256(pin) == hash) {
                _state.value = _state.value.copy(isAuthenticated = true)
            } else {
                _state.value = _state.value.copy(showError = true, enteredPin = "")
                viewModelScope.launch {
                    delay(1200)
                    _state.value = _state.value.copy(showError = false)
                }
            }
        }
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
