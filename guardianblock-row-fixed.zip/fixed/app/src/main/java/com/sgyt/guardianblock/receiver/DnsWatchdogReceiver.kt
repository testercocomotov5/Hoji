package com.sgyt.guardianblock.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import com.sgyt.guardianblock.data.local.PreferencesManager
import com.sgyt.guardianblock.service.PrivateDnsService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * DnsWatchdogReceiver
 *
 * Fired every [INTERVAL_MS] by AlarmManager.  If DNS protection is enabled but the
 * service is not running (killed by the OS), it restarts it.  Ensures 24/7 operation.
 *
 * Bug fixes in v9:
 *
 *   [BUG-Watchdog FIX] The old implementation used [AlarmManager.setRepeating], which is
 *   documented as INEXACT since Android 4.4 and is effectively SUSPENDED during Doze mode
 *   (Android 6+).  On a device with screen off, the repeating alarm could be batched and
 *   delayed by hours, defeating the entire purpose of the watchdog.
 *
 *   The fix uses a one-shot [AlarmManager.setExactAndAllowWhileIdle], which fires even in
 *   Doze mode, and reschedules itself inside [onReceive] to maintain the cadence.
 *   The SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM permissions declared in the manifest are
 *   actually honoured this way — setRepeating ignores them entirely.
 */
@AndroidEntryPoint
class DnsWatchdogReceiver : BroadcastReceiver() {

    @Inject lateinit var prefsManager: PreferencesManager

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val config = prefsManager.getBlockConfig().first()
                if (config.isDnsEnabled) {
                    val permIntent = VpnService.prepare(context)
                    if (permIntent == null) {
                        context.startForegroundService(
                            Intent(context, PrivateDnsService::class.java).apply {
                                action = PrivateDnsService.ACTION_START
                            }
                        )
                    }
                }
            } finally {
                // BUG-Watchdog FIX: reschedule the next exact one-shot alarm before finishing.
                // This keeps the chain alive without relying on inexact setRepeating.
                schedule(context)
                pendingResult.finish()
            }
        }
    }

    companion object {
        private const val REQUEST_CODE = 9876
        private const val INTERVAL_MS  = 3 * 60 * 1000L   // 3 minutes

        fun schedule(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = buildPendingIntent(context)
            val triggerAt = System.currentTimeMillis() + INTERVAL_MS

            // BUG-Watchdog FIX: use setExactAndAllowWhileIdle so the alarm fires even
            // during Doze mode.  setRepeating (old code) is inexact on API 19+ and paused
            // during Doze on API 23+, making the watchdog useless when the screen is off.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        }

        fun cancel(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(buildPendingIntent(context))
        }

        private fun buildPendingIntent(context: Context): PendingIntent {
            val i = Intent(context, DnsWatchdogReceiver::class.java)
            return PendingIntent.getBroadcast(
                context, REQUEST_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
