package com.sgyt.guardianblock.ui.lockscreen

import androidx.compose.animation.core.tween

/** Animation specs — GPU-accelerated, no layout-passing properties.
 *  Only animate: translation, rotation, scale, alpha */
object LockAnimations {
    // Error shake — exact timing, do not change
    val ErrorShakeMS   = 500
    val ErrorShakeDamp = 200  // fade-out delay

    // Dial hole press — tactile, no bounce
    val HolePressMS    = 100

    // Method switch — fast fade
    val MethodFadeMS   = 250

    // Status text cross-fade
    val StatusFadeMS   = 200
}
