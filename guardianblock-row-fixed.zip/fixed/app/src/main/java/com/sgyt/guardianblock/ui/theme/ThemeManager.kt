package com.sgyt.guardianblock.ui.theme

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// BUG-1 FIX: file-level extension — avoids JVM platform declaration clash with
// PreferencesManager's Context.dataStore which lives in a different file.
private val Context.themePreferencesDataStore: DataStore<Preferences>
        by preferencesDataStore(name = "theme_preferences")

class ThemeManager(private val context: Context) {

    companion object {
        private val THEME_KEY = stringPreferencesKey("app_theme")

        enum class AppTheme(val displayName: String) {
            LIGHT("Light"),
            DARK("Dark"),
            SWISS_LIGHT("Swiss Light"),
            SWISS_DARK("Swiss Dark")
        }

        val DEFAULT_THEME = AppTheme.SWISS_LIGHT
    }

    val appTheme: Flow<AppTheme> = context.themePreferencesDataStore.data
        .map { preferences ->
            val themeName = preferences[THEME_KEY]
            try {
                themeName?.let { AppTheme.valueOf(it) } ?: DEFAULT_THEME
            } catch (e: IllegalArgumentException) {
                DEFAULT_THEME
            }
        }

    val isDarkTheme: Flow<Boolean> = appTheme.map { theme ->
        theme == AppTheme.DARK || theme == AppTheme.SWISS_DARK
    }

    suspend fun setTheme(theme: AppTheme) {
        context.themePreferencesDataStore.edit { preferences ->
            preferences[THEME_KEY] = theme.name
        }
    }

    fun getThemeFromName(name: String): AppTheme {
        return try {
            AppTheme.valueOf(name)
        } catch (e: IllegalArgumentException) {
            DEFAULT_THEME
        }
    }
}
