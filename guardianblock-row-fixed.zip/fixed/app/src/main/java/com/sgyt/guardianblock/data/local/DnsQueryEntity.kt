package com.sgyt.guardianblock.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dns_queries")
data class DnsQueryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val domain: String,
    val blocked: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
