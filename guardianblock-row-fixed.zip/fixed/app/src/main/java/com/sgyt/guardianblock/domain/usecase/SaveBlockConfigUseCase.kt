package com.sgyt.guardianblock.domain.usecase

import com.sgyt.guardianblock.domain.model.BlockConfig
import com.sgyt.guardianblock.domain.repository.BlockRepository
import javax.inject.Inject

class SaveBlockConfigUseCase @Inject constructor(private val repository: BlockRepository) {
    suspend operator fun invoke(config: BlockConfig) = repository.saveBlockConfig(config)
}
