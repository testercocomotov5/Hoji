package com.sgyt.guardianblock.domain.usecase

import com.sgyt.guardianblock.domain.model.BlockConfig
import com.sgyt.guardianblock.domain.repository.BlockRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetBlockConfigUseCase @Inject constructor(private val repository: BlockRepository) {
    operator fun invoke(): Flow<BlockConfig> = repository.getBlockConfig()
}
