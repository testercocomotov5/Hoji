package com.sgyt.guardianblock.domain.model

data class DnsQuery(
    val id: Long,
    val domain: String,
    val timestamp: Long,
    val blocked: Boolean,
    val queryType: String = "A"
)
