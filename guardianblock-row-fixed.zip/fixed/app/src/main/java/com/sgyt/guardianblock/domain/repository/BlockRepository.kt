package com.sgyt.guardianblock.domain.repository

import com.sgyt.guardianblock.domain.model.BlockConfig
import kotlinx.coroutines.flow.Flow

interface BlockRepository {
    fun getBlockConfig(): Flow<BlockConfig>
    suspend fun saveBlockConfig(config: BlockConfig)
    suspend fun addKeyword(keyword: String)
    suspend fun removeKeyword(keyword: String)
    suspend fun getPinHash(): String
    suspend fun savePinHash(hash: String)
}
