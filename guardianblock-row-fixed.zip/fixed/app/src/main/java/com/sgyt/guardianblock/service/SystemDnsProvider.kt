package com.sgyt.guardianblock.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import dagger.hilt.android.qualifiers.ApplicationContext
import java.net.InetAddress
import javax.inject.Inject
import javax.inject.Singleton

/**
 * SystemDnsProvider
 *
 * Reads the device's own DNS servers from [ConnectivityManager.getLinkProperties] — the exact
 * same servers Android itself would use for normal DNS resolution.  No hardcoded addresses.
 *
 * Design:
 *   • Queries the PHYSICAL network (non-VPN) via cm.allNetworks filtered by !TRANSPORT_VPN.
 *     Using cm.activeNetwork is WRONG when GuardianBlock's own VPN is active because
 *     activeNetwork returns the VPN network whose dnsServers = [10.99.0.2] (our virtual IP),
 *     creating an infinite forwarding loop.  (BUG-B fix)
 *   • Cached for [CACHE_TTL_MS] (5 s) so thousands of concurrent queries don't hammer the CM API
 *   • Falls back through the full server list — loopback / link-local / unspecified are skipped
 *   • If no usable servers found → returns empty list → caller sends SERVFAIL immediately
 *
 * Thread-safety: [getServers] is @Synchronized so it is safe to call from parallel coroutines.
 */
@Singleton
class SystemDnsProvider @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val CACHE_TTL_MS = 5_000L  // re-read ConnectivityManager every 5 s max
    }

    @Volatile private var cachedServers: List<InetAddress> = emptyList()
    @Volatile private var cacheExpiry: Long = 0L

    /**
     * Returns the device's current upstream DNS servers from the physical (non-VPN) network.
     * Loopback / link-local / unspecified addresses are excluded.
     */
    @Synchronized
    fun getServers(): List<InetAddress> {
        val now = System.currentTimeMillis()
        if (now < cacheExpiry && cachedServers.isNotEmpty()) return cachedServers

        val fresh = readFromConnectivityManager()
        cachedServers = fresh
        cacheExpiry   = now + CACHE_TTL_MS
        return fresh
    }

    /** Force-invalidate the cache (called when the active network changes). */
    @Synchronized
    fun invalidate() { cacheExpiry = 0L }

    // -------------------------------------------------------------------------

    private fun readFromConnectivityManager(): List<InetAddress> {
        return try {
            val cm = context.getSystemService(ConnectivityManager::class.java) ?: return emptyList()

            // BUG-B FIX: use allNetworks filtered by !TRANSPORT_VPN so we never read our own
            // VPN network's link properties (which would return 10.99.0.2 and cause an
            // infinite DNS forwarding loop).  Pick the first usable physical network.
            val physicalNetwork = cm.allNetworks.firstOrNull { network ->
                val caps = cm.getNetworkCapabilities(network) ?: return@firstOrNull false
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            } ?: return emptyList()

            val lp = cm.getLinkProperties(physicalNetwork) ?: return emptyList()

            lp.dnsServers
                .filter { addr ->
                    val raw = addr.address
                    // Skip loopback — would re-enter our own VPN tunnel
                    !addr.isLoopbackAddress &&
                    // Skip link-local fe80:: addresses (not reachable via protected socket)
                    !addr.isLinkLocalAddress &&
                    // Skip wildcard / unspecified
                    raw != null && !raw.all { it == 0.toByte() }
                }
        } catch (_: Exception) { emptyList() }
    }
}
