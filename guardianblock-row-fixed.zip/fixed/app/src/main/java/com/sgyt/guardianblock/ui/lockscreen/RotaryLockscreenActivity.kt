package com.sgyt.guardianblock.ui.lockscreen

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.sgyt.guardianblock.R
import com.sgyt.guardianblock.view.RotaryDialView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import java.text.SimpleDateFormat
import java.util.*

/**
 * RotaryLockscreenActivity — the app's entry-point lockscreen.
 *
 * FUSION: launched from MainActivity with startActivityForResult().
 * On passcode success it delivers setResult(RESULT_OK) and finishes,
 * letting MainActivity start the Compose UI.
 *
 * BUG-10 FIX: deprecated systemUiVisibility replaced with WindowInsetsController.
 * BUG-11 FIX: deprecated onBackPressed() override replaced with OnBackPressedCallback.
 * BUG-4  FIX: date text no longer hard-coded; updateClock() formats dynamically.
 */
class RotaryLockscreenActivity : AppCompatActivity() {

    private lateinit var rotaryDialView: RotaryDialView
    private lateinit var passcodeDotsContainer: LinearLayout
    private lateinit var lockIcon: ImageView
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var statusText: TextView
    private lateinit var successOverlay: View

    private lateinit var passcodeManager: PasscodeManager
    private val enteredPasscode = StringBuilder()
    private val dots = mutableListOf<View>()

    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rotary_lockscreen)

        // BUG-10 FIX: use WindowInsetsController (API 30+) with legacy fallback.
        hideSystemUi()

        // BUG-11 FIX: prevent back via OnBackPressedCallback instead of
        // deprecated onBackPressed() override.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // intentionally empty — back is blocked on the lockscreen
            }
        })

        passcodeManager = PasscodeManager(this)

        // If no passcode is configured yet, send OK so MainActivity can
        // proceed directly to PIN setup / dashboard.
        if (!passcodeManager.hasPasscode()) {
            setResult(Activity.RESULT_OK)
            finish()
            return
        }

        initViews()
        setupRotaryDial()
        createPasscodeDots()
        updateClock()
        handler.post(clockRunnable)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { ctrl ->
                ctrl.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                ctrl.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    private fun initViews() {
        rotaryDialView         = findViewById(R.id.rotaryDialView)
        passcodeDotsContainer  = findViewById(R.id.passcodeDotsContainer)
        lockIcon               = findViewById(R.id.lockIcon)
        clockText              = findViewById(R.id.clockText)
        dateText               = findViewById(R.id.dateText)
        statusText             = findViewById(R.id.statusText)
        successOverlay         = findViewById(R.id.successOverlay)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(left = bars.left, top = bars.top,
                            right = bars.right, bottom = bars.bottom)
            insets
        }
    }

    private fun setupRotaryDial() {
        rotaryDialView.onNumberSelectedListener = object : RotaryDialView.OnNumberSelectedListener {
            override fun onNumberSelected(number: Int) { onDigitEntered(number) }
        }
    }

    private fun createPasscodeDots() {
        passcodeDotsContainer.removeAllViews()
        dots.clear()

        val dotSize   = resources.getDimensionPixelSize(R.dimen.passcode_dot_size)
        val dotMargin = resources.getDimensionPixelSize(R.dimen.passcode_dot_margin)

        repeat(4) { index ->
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dotSize, dotSize).apply {
                    marginStart = if (index == 0) 0 else dotMargin
                    marginEnd   = if (index == 3) 0 else dotMargin
                }
                // BUG-12 FIX (minor): ContextCompat.getDrawable avoids deprecated getDrawable()
                background = ContextCompat.getDrawable(this@RotaryLockscreenActivity,
                                                        R.drawable.passcode_dot_empty)
            }
            dots.add(dot)
            passcodeDotsContainer.addView(dot)
        }
    }

    private fun onDigitEntered(digit: Int) {
        if (enteredPasscode.length < 4) {
            enteredPasscode.append(digit)
            updateDots()
            if (enteredPasscode.length == 4) {
                handler.postDelayed({ checkPasscode() }, 200)
            }
        }
    }

    private fun updateDots() {
        dots.forEachIndexed { index, dot ->
            dot.background = ContextCompat.getDrawable(
                this,
                if (index < enteredPasscode.length) R.drawable.passcode_dot_filled
                else R.drawable.passcode_dot_empty
            )
        }
        if (enteredPasscode.isNotEmpty()) {
            dots.getOrNull(enteredPasscode.length - 1)?.let { dot ->
                dot.animate().scaleX(1.3f).scaleY(1.3f).setDuration(100)
                    .withEndAction {
                        dot.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                    }.start()
            }
        }
    }

    private fun checkPasscode() {
        if (passcodeManager.isPasscodeCorrect(enteredPasscode.toString())) onUnlockSuccess()
        else onUnlockFailed()
    }

    private fun onUnlockSuccess() {
        lockIcon.background = ContextCompat.getDrawable(this, R.drawable.ic_lock_open)
        lockIcon.background?.setTint(ContextCompat.getColor(this, R.color.success_green))

        lockIcon.animate().scaleX(1.2f).scaleY(1.2f).setDuration(200)
            .setInterpolator(OvershootInterpolator())
            .withEndAction {
                lockIcon.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
            }.start()

        successOverlay.visibility = View.VISIBLE
        successOverlay.animate().alpha(1f).setDuration(300).start()

        // FUSION: deliver RESULT_OK so MainActivity can start Compose content.
        handler.postDelayed({
            setResult(Activity.RESULT_OK)
            finish()
        }, 1_200)
    }

    private fun onUnlockFailed() {
        ObjectAnimator.ofFloat(passcodeDotsContainer, "translationX",
                               0f, -20f, 20f, -20f, 20f, 0f).apply {
            duration = 400; start()
        }
        ObjectAnimator.ofFloat(lockIcon, "translationX",
                               0f, -10f, 10f, -10f, 10f, 0f).apply {
            duration = 400; start()
        }
        dots.forEach { dot ->
            dot.background = ContextCompat.getDrawable(this, R.drawable.passcode_dot_error)
        }
        handler.postDelayed({ resetPasscode() }, 400)
    }

    private fun resetPasscode() {
        enteredPasscode.clear()
        dots.forEach { it.background = ContextCompat.getDrawable(this, R.drawable.passcode_dot_empty) }
        rotaryDialView.reset()
    }

    private fun updateClock() {
        val cal = Calendar.getInstance()
        clockText.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(cal.time)
        // BUG-4 FIX: was hardcoded "Monday, January 1" in XML; now always dynamic.
        dateText.text  = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(cal.time)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(clockRunnable)
    }
}
