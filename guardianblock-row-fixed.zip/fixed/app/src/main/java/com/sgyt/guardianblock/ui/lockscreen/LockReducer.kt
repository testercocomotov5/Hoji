package com.sgyt.guardianblock.ui.lockscreen

/** Pure reducer: (state, event) -> new state. */
object LockReducer {

    fun reduce(state: LockUiState, event: LockEvent): LockUiState {
        return when (event) {

            LockEvent.AddDigit -> {
                state  // ViewModel handles append directly
            }

            LockEvent.RemoveDigit -> {
                if (state.digitBuffer.isEmpty()) {
                    state
                } else {
                    val newBuffer = state.digitBuffer.dropLast(1)
                    state.copy(
                        digitBuffer  = newBuffer,
                        lockState    = if (newBuffer.isEmpty()) LockState.Idle else LockState.Inputting,
                        errorMessage = null
                    )
                }
            }

            LockEvent.SelectPatternNode -> {
                state  // ViewModel handles node selection directly
            }

            LockEvent.CancelPattern -> {
                state.copy(
                    patternNodes = emptyList(),
                    lockState    = LockState.Idle
                )
            }

            LockEvent.Submit -> {
                if (!state.canSubmit) state
                else state.copy(lockState = LockState.Validating)
            }

            LockEvent.AuthSuccess -> {
                state.copy(
                    isAuthenticated = true,
                    lockState       = LockState.Success,
                    digitBuffer     = emptyList(),
                    patternNodes    = emptyList()
                )
            }

            is LockEvent.AuthFailure -> {
                val newCount = state.failureCount + 1
                if (newCount >= LockTokens.MAX_FAILURES) {
                    state.copy(
                        lockState      = LockState.LockedOut,
                        failureCount   = newCount,
                        lockoutEndTime = System.currentTimeMillis() + LockTokens.LOCKOUT_MS,
                        errorMessage   = event.error,
                        digitBuffer    = emptyList(),
                        patternNodes   = emptyList()
                    )
                } else {
                    state.copy(
                        lockState      = LockState.Error,
                        failureCount   = newCount,
                        errorMessage   = event.error,
                        digitBuffer    = emptyList(),
                        patternNodes   = emptyList()
                    )
                }
            }

            LockEvent.DismissError -> {
                state.copy(
                    lockState    = LockState.Idle,
                    errorMessage = null,
                    digitBuffer  = emptyList(),
                    patternNodes = emptyList()
                )
            }

            is LockEvent.ChangeMethod -> {
                if (state.lockState == LockState.LockedOut) state
                else state.copy(
                    method       = event.method,
                    digitBuffer  = emptyList(),
                    patternNodes = emptyList(),
                    lockState    = LockState.Idle,
                    errorMessage = null
                )
            }

            LockEvent.LockoutEnded -> {
                state.copy(
                    lockState      = LockState.Idle,
                    failureCount   = 0,
                    lockoutEndTime = null,
                    errorMessage   = null
                )
            }

            LockEvent.DnsCheckStarted -> {
                state
            }

            is LockEvent.DnsCheckSuccess -> {
                state.copy(errorMessage = null)
            }

            is LockEvent.DnsCheckFailure -> {
                state.copy(errorMessage = event.error)
            }

            is LockEvent.DnsQueryCaptured -> {
                val queries = if (state.queries.size >= LockTokens.MAX_DNS_QUERIES) {
                    state.queries.drop(state.queries.size - LockTokens.MAX_DNS_QUERIES + 1) + event.query
                } else {
                    state.queries + event.query
                }
                state.copy(queries = queries)
            }
        }
    }
}
