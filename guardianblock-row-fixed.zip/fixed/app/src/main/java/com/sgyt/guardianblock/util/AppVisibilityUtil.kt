package com.sgyt.guardianblock.util

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppVisibilityUtil @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val adminComponent =
        ComponentName(context, "com.sgyt.guardianblock.receiver.AdminReceiver")

    fun isDeviceAdminActive(): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent)
    }

    fun removeDeviceAdmin() {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(adminComponent)) dpm.removeActiveAdmin(adminComponent)
    }

    fun getAdminComponent(): ComponentName = adminComponent
}
