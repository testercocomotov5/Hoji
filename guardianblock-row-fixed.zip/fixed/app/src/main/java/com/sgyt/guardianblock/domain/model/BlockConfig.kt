package com.sgyt.guardianblock.domain.model

data class BlockConfig(
    val isDnsEnabled: Boolean = true,
    val keywords: Map<String, Boolean> = defaultKeywords(),
    val pinHash: String = ""
) {
    companion object {
        fun defaultKeywords(): Map<String, Boolean> = linkedMapOf(
            "book"     to true,
            "reddy"    to true,
            "club"     to true,
            "daman"    to true,
            "tiranga"  to true,
            "bet"      to true,
            "11x"      to true,
            "crex"     to true,
            "exch"     to true,
            "exchange" to true,
            "play"     to true
        )

        /** Keywords that cannot be deleted by the user */
        val PROTECTED_KEYWORDS = setOf("bet", "exch", "exchange")
    }
}
