package com.sgyt.guardianblock.ui.navigation

sealed class Screen(val route: String) {
    object LockScreen  : Screen("lock")
    object Dashboard   : Screen("dashboard")
    object Settings    : Screen("settings")
    object Queries     : Screen("queries")
}
