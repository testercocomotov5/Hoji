package com.sgyt.guardianblock.ui.settings

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sgyt.guardianblock.domain.model.BlockConfig
import com.sgyt.guardianblock.ui.theme.ThemeManager
import com.sgyt.guardianblock.ui.theme.themeColors

// BUG-7 FIX: Scaffold containerColor and all other hardcoded colors
// replaced with themeColors() / MaterialTheme.colorScheme equivalents.

@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state   by viewModel.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context  = LocalContext.current
    val tc       = themeColors()

    val adminLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) viewModel.onAdminActivated()
        else viewModel.onAdminDenied()
    }

    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let { snackbar.showSnackbar(it); viewModel.clearToast() }
    }
    LaunchedEffect(state.requestAdminIntent) {
        state.requestAdminIntent?.let { adminLauncher.launch(it); viewModel.clearAdminIntentRequest() }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshAccessibilityState()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Scaffold(
        containerColor = tc.background,              // ← theme-aware (was Color.White)
        snackbarHost = {
            SnackbarHost(snackbar) { data ->
                Snackbar(
                    snackbarData   = data,
                    containerColor = tc.surface,
                    contentColor   = tc.textPrimary,
                    actionColor    = tc.accent,
                    shape          = RoundedCornerShape(14.dp)
                )
            }
        },
        topBar = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(tc.background)        // ← theme-aware
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick  = onNavigateBack,
                        modifier = Modifier.size(40.dp)
                            .background(tc.surface, RoundedCornerShape(12.dp))
                    ) {
                        Icon(Icons.Rounded.ArrowBack, "Back", tint = tc.textPrimary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("Settings", style = MaterialTheme.typography.titleLarge,
                        color = tc.textPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // Theme
            SettingsSectionCard(Icons.Rounded.Palette, "Theme", Color(0xFF1A5FB4)) {
                ThemeSelector(
                    currentTheme    = state.currentTheme,
                    onThemeSelected = { viewModel.setTheme(it) },
                    availableThemes = viewModel.getAvailableThemes()
                )
            }

            // Keywords
            SettingsSectionCard(Icons.Rounded.Block, "Blocked Keywords", Color(0xFFE30613)) {
                Row(
                    Modifier.fillMaxWidth(),
                    Arrangement.spacedBy(10.dp), Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value         = state.newKeywordText,
                        onValueChange = { viewModel.onNewKeywordChanged(it) },
                        placeholder   = { Text("Add keyword…", color = tc.textDisabled) },
                        singleLine    = true,
                        modifier      = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { viewModel.addKeyword() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor   = tc.accent,
                            unfocusedBorderColor = tc.border,
                            focusedTextColor     = tc.textPrimary,
                            unfocusedTextColor   = tc.textPrimary,
                            cursorColor          = tc.accent
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
                    IconButton(
                        onClick  = { viewModel.addKeyword() },
                        modifier = Modifier.size(52.dp)
                            .background(tc.accent, RoundedCornerShape(14.dp))
                    ) {
                        Icon(Icons.Rounded.Add, "Add", tint = Color.White)
                    }
                }

                Spacer(Modifier.height(4.dp))

                state.config.keywords.forEach { (keyword, enabled) ->
                    val isDefault   = keyword in BlockConfig.defaultKeywords().keys
                    val isProtected = keyword in BlockConfig.PROTECTED_KEYWORDS
                    KeywordRow(
                        keyword     = keyword,
                        enabled     = enabled,
                        isProtected = isProtected,
                        isDefault   = isDefault,
                        onToggle    = { viewModel.toggleKeyword(keyword, it) },
                        onDelete    = { viewModel.removeKeyword(keyword) }
                    )
                    if (keyword != state.config.keywords.keys.last()) {
                        HorizontalDivider(Modifier.padding(vertical = 2.dp),
                            color = tc.borderLight, thickness = 0.5.dp)
                    }
                }
            }

            // Stealth mode
            SettingsSectionCard(Icons.Rounded.VisibilityOff, "Stealth Mode", Color(0xFF3A3A3A)) {
                StatusToggleRow(
                    active         = state.isAccessibilityEnabled,
                    activeLabel    = "Stealth ACTIVE",
                    inactiveLabel  = "Stealth INACTIVE",
                    activeSubLabel = "Notifications hidden. Admin removal blocked.",
                    inactiveSubLabel = "Enable to activate full stealth protection",
                    onEnable = {
                        context.startActivity(
                            android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .apply { flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK }
                        )
                    }
                )
                AnimatedVisibility(!state.isAccessibilityEnabled) {
                    InfoHint("In Accessibility settings → find 'System Services' → toggle on.")
                }
            }

            // Uninstall protection
            SettingsSectionCard(Icons.Rounded.AdminPanelSettings, "Uninstall Protection", Color(0xFFFFB300)) {
                StatusToggleRow(
                    active           = state.isDeviceAdminActive,
                    activeLabel      = "Protection ACTIVE",
                    inactiveLabel    = "Protection INACTIVE",
                    activeSubLabel   = "App cannot be uninstalled. Dial *#*#1253#*#* to remove.",
                    inactiveSubLabel = "Enable to prevent uninstallation",
                    onEnable         = { viewModel.requestDeviceAdmin() }
                )
            }

            // Secret access
            SettingsSectionCard(Icons.Rounded.Key, "Secret Access", Color(0xFF3A3A3A)) {
                AccessRow(Icons.Rounded.Dialpad,  "Open app",      "Dial *#*#7467#*#* in Phone app")
                Spacer(Modifier.height(8.dp))
                AccessRow(Icons.Rounded.LockOpen, "Remove admin",  "Dial *#*#1253#*#* to allow uninstall")
                Spacer(Modifier.height(8.dp))
                AccessRow(Icons.Rounded.Autorenew,"Always-on",     "DNS protection restarts automatically after every reboot")
            }

            Spacer(Modifier.height(28.dp))
        }
    }
}

// ── Theme Selector ────────────────────────────────────────────────────────────

@Composable
private fun ThemeSelector(
    currentTheme: ThemeManager.AppTheme,
    onThemeSelected: (ThemeManager.AppTheme) -> Unit,
    availableThemes: List<ThemeManager.AppTheme>
) {
    val tc = themeColors()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(tc.surface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            availableThemes.forEach { theme ->
                ThemeSegmentButton(
                    theme      = theme,
                    isSelected = currentTheme == theme,
                    onClick    = { onThemeSelected(theme) },
                    modifier   = Modifier.weight(1f)
                )
            }
        }
        ThemePreviewCard(currentTheme)
    }
}

@Composable
private fun ThemeSegmentButton(
    theme: ThemeManager.AppTheme,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tc = themeColors()
    val backgroundColor by animateColorAsState(
        if (isSelected) tc.background else Color.Transparent, tween(200), "bgC")
    val textColor by animateColorAsState(
        if (isSelected) Color(0xFF1A5FB4) else tc.textSecondary, tween(200), "tC")

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .then(if (isSelected)
                Modifier.border(1.dp, Color(0xFF1A5FB4).copy(0.3f), RoundedCornerShape(8.dp))
            else Modifier)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(theme.displayName, style = MaterialTheme.typography.labelMedium,
            color = textColor,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1)
    }
}

@Composable
private fun ThemePreviewCard(theme: ThemeManager.AppTheme) {
    val tc = themeColors()
    val (bg, surf, primary, text, subText) = when (theme) {
        ThemeManager.AppTheme.LIGHT      -> Tuple5(Color.White, Color(0xFFF7F7F7), Color(0xFFE30613), Color(0xFF1A1A1A), Color(0xFF666666))
        ThemeManager.AppTheme.DARK       -> Tuple5(Color(0xFF1A1A1A), Color(0xFF2A2A2A), Color(0xFFE30613), Color.White, Color(0xFFB0B0B0))
        ThemeManager.AppTheme.SWISS_LIGHT -> Tuple5(Color.White, Color(0xFFF7F7F7), Color(0xFFE30613), Color(0xFF1A1A1A), Color(0xFF666666))
        ThemeManager.AppTheme.SWISS_DARK  -> Tuple5(Color(0xFF1A1A1A), Color(0xFF2A2A2A), Color(0xFFE30613), Color.White, Color(0xFFB0B0B0))
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, tc.border, RoundedCornerShape(12.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Preview", style = MaterialTheme.typography.labelMedium, color = subText)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(primary))
                Box(Modifier.size(8.dp).clip(CircleShape).background(subText))
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFFB300)))
            }
        }
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(surf).padding(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Sample Title", style = MaterialTheme.typography.bodyMedium,
                    color = text, fontWeight = FontWeight.Medium)
                Text("This is how content will appear.",
                    style = MaterialTheme.typography.bodySmall, color = subText)
            }
        }
        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(primary)
            .padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("Action Button", style = MaterialTheme.typography.labelMedium,
                color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}

private data class Tuple5<A, B, C, D, E>(val a: A, val b: B, val c: C, val d: D, val e: E)
private operator fun <A, B, C, D, E> Tuple5<A, B, C, D, E>.component1() = a
private operator fun <A, B, C, D, E> Tuple5<A, B, C, D, E>.component2() = b
private operator fun <A, B, C, D, E> Tuple5<A, B, C, D, E>.component3() = c
private operator fun <A, B, C, D, E> Tuple5<A, B, C, D, E>.component4() = d
private operator fun <A, B, C, D, E> Tuple5<A, B, C, D, E>.component5() = e

// ── Sub-composables ───────────────────────────────────────────────────────────

@Composable
private fun KeywordRow(
    keyword: String, enabled: Boolean, isProtected: Boolean,
    isDefault: Boolean, onToggle: (Boolean) -> Unit, onDelete: () -> Unit
) {
    val tc = themeColors()
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically
    ) {
        Row(Modifier.weight(1f), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
            Switch(
                checked         = enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedTrackColor    = tc.accent,
                    checkedBorderColor   = tc.accent,
                    uncheckedTrackColor  = tc.surface,
                    uncheckedBorderColor = tc.border
                )
            )
            Column {
                Text(keyword, style = MaterialTheme.typography.bodyLarge, color = tc.textPrimary)
                Text(
                    when {
                        isProtected -> "Protected — cannot be removed"
                        isDefault   -> "Default keyword"
                        else        -> "Custom keyword"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isProtected) Color(0xFFFFB300) else tc.textDisabled
                )
            }
        }
        if (!isProtected) {
            IconButton(onClick = onDelete) {
                Icon(Icons.Rounded.DeleteOutline, "Remove",
                    tint = if (isDefault) tc.border else tc.accent.copy(0.7f),
                    modifier = Modifier.size(20.dp))
            }
        } else {
            Icon(Icons.Rounded.Lock, null, tint = Color(0xFFFFB300),
                modifier = Modifier.padding(12.dp).size(16.dp))
        }
    }
}

@Composable
private fun StatusToggleRow(
    active: Boolean, activeLabel: String, inactiveLabel: String,
    activeSubLabel: String, inactiveSubLabel: String, onEnable: () -> Unit
) {
    val tc = themeColors()
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(if (active) activeLabel else inactiveLabel,
                style = MaterialTheme.typography.bodyLarge,
                color = if (active) Color(0xFF00843D) else tc.accent,
                fontWeight = FontWeight.SemiBold)
            Text(if (active) activeSubLabel else inactiveSubLabel,
                style = MaterialTheme.typography.labelSmall, color = tc.textSecondary)
        }
        AnimatedContent(active,
            transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "toggle") { on ->
            if (on) {
                Box(
                    Modifier.size(36.dp)
                        .background(Color(0xFF00843D).copy(0.12f), CircleShape)
                        .border(1.dp, Color(0xFF00843D).copy(0.4f), CircleShape),
                    Alignment.Center
                ) {
                    Icon(Icons.Rounded.Check, null,
                        tint = Color(0xFF00843D), modifier = Modifier.size(20.dp))
                }
            } else {
                Button(
                    onClick  = onEnable,
                    colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFFB90524)),
                    shape    = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text("Enable", fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun AccessRow(icon: ImageVector, title: String, desc: String) {
    val tc = themeColors()
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).background(tc.surface, RoundedCornerShape(10.dp)),
            Alignment.Center) {
            Icon(icon, null, tint = tc.textPrimary, modifier = Modifier.size(17.dp))
        }
        Column {
            Text(title, style = MaterialTheme.typography.bodyMedium,
                color = tc.textPrimary, fontWeight = FontWeight.Medium)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = tc.textDisabled)
        }
    }
}

@Composable
private fun InfoHint(text: String) {
    val tc = themeColors()
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp)
            .background(tc.surface, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(Icons.Rounded.Info, null, tint = tc.textDisabled,
            modifier = Modifier.size(15.dp).padding(top = 1.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = tc.textSecondary)
    }
}

@Composable
private fun SettingsSectionCard(
    icon: ImageVector, title: String, color: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    val tc = themeColors()
    Box(
        Modifier.fillMaxWidth()
            .background(tc.background, RoundedCornerShape(20.dp))  // ← was Color.White
            .border(1.dp, tc.border, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).background(color.copy(0.10f), RoundedCornerShape(10.dp)),
                    Alignment.Center) {
                    Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
                }
                Text(title, style = MaterialTheme.typography.titleMedium,
                    color = tc.textPrimary, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}
