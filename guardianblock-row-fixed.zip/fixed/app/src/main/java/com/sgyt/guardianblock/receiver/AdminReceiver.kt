package com.sgyt.guardianblock.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
    }

    /**
     * Called when user tries to remove this app from Device Admins via Settings.
     * Returns a warning string shown in the confirmation dialog.
     * To legitimately remove admin, dial *#*#1253#*#* in the phone app.
     */
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "WARNING: This is a critical system security component. " +
               "Removing it will disable device protection and may cause system instability. " +
               "Contact your system administrator before proceeding."
    }
}
