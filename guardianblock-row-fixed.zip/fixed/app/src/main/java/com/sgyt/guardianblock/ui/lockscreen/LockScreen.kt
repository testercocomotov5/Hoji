package com.sgyt.guardianblock.ui.lockscreen

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Stable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sgyt.guardianblock.domain.model.DnsQuery
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

// ═══════════════════════════════════════════════════════════
// LockScreen — public entry point
// ═══════════════════════════════════════════════════════════

@Composable
fun LockScreen(
    onAuthenticated: () -> Unit,
    viewModel: LockScreenViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.isAuthenticated) {
        if (state.isAuthenticated) onAuthenticated()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(LockTokens.White)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = LockTokens.MD.dp)
                .statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(LockTokens.LG.dp, Alignment.CenterVertically)
        ) {
            // ── Method selector ──────────────────────────
            MethodSelector(
                current = state.method,
                onMethodSelected = viewModel::onMethodChanged
            )

            // ── Lock icon ────────────────────────────────
            Box(
                Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(LockTokens.Sunken),
                contentAlignment = Alignment.Center
            ) {
                if (state.pinHash.isEmpty()) {
                    Icon(
                        Icons.Rounded.Add, null,
                        tint = LockTokens.SwissRed,
                        modifier = Modifier.size(28.dp)
                    )
                } else {
                    Icon(
                        Icons.Rounded.Lock, null,
                        tint = LockTokens.SwissRed,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // ── Title ────────────────────────────────────
            val titleText = when (state.method) {
                LockMethod.FourDigit -> if (state.pinHash.isEmpty()) "Set PIN" else "Enter 4-Digit PIN"
                LockMethod.SixDigit -> if (state.pinHash.isEmpty()) "Set PIN" else "Enter 6-Digit PIN"
                LockMethod.Pattern -> if (state.pinHash.isEmpty()) "Set Pattern" else "Draw Pattern"
            }

            Text(
                titleText,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = LockTokens.TextPrimary,
                letterSpacing = (-0.3).sp
            )

            // ── Digit dots or pattern spacer ─────────────
            when (state.method) {
                LockMethod.FourDigit -> DigitDots(
                    buffer = state.digitBuffer,
                    maxDigits = LockTokens.MAX_DIGITS_4,
                    isError = state.lockState == LockState.Error,
                    isLocked = state.lockState == LockState.LockedOut
                )
                LockMethod.SixDigit -> DigitDots(
                    buffer = state.digitBuffer,
                    maxDigits = LockTokens.MAX_DIGITS_6,
                    isError = state.lockState == LockState.Error,
                    isLocked = state.lockState == LockState.LockedOut
                )
                LockMethod.Pattern -> Spacer(Modifier.height(24.dp))
            }

            // ── Error / lockout message ──────────────────
            ErrorMessageDisplay(state)

            // ── Input method ─────────────────────────────
            AnimatedContent(
                state.method,
                transitionSpec = {
                    fadeIn(tween(LockAnimations.MethodFadeMS)) togetherWith
                    fadeOut(tween(LockAnimations.MethodFadeMS - 50))
                },
                label = "methodSwitch"
            ) { method ->
                when (method) {
                    LockMethod.FourDigit,
                    LockMethod.SixDigit -> DialPadGrid(
                        onDigitTap = viewModel::onDigitEntered,
                        onBackspace = viewModel::onBackspace,
                        locked = state.lockState == LockState.LockedOut
                    )
                    LockMethod.Pattern -> PatternGridView(
                        nodes = state.patternNodes,
                        isLocked = state.lockState == LockState.LockedOut,
                        isError = state.lockState == LockState.Error,
                        onNodeSelected = viewModel::onPatternNodeSelected,
                        onCancel = viewModel::onCancelPattern
                    )
                }
            }

            // ── DNS queries section ──────────────────────
            DnsQueriesSection(
                queries = state.queries,
                liveEnabled = state.liveQueryEnabled,
                onToggleLive = viewModel::onLiveQueryToggled,
                onClearAll = viewModel::onClearQueries
            )

            Spacer(Modifier.height(LockTokens.LG.dp))
        }
    }
}

// ═══════════════════════════════════════════════════════════
// MethodSelector — tab switcher
// ═══════════════════════════════════════════════════════════

@Composable
private fun MethodSelector(
    current: LockMethod,
    onMethodSelected: (LockMethod) -> Unit
) {
    val methods = listOf(
        "4-DIGIT" to LockMethod.FourDigit,
        "6-DIGIT" to LockMethod.SixDigit,
        "PATTERN" to LockMethod.Pattern
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(LockTokens.SM.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(methods) { (label, method) ->
            TabButton(
                label = label,
                active = method == current,
                onClick = { onMethodSelected(method) }
            )
        }
    }
}

@Composable
private fun TabButton(
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .clip(RoundedCornerShape(LockTokens.SM.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = LockTokens.SM.dp, vertical = LockTokens.XS.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) LockTokens.TextPrimary else LockTokens.TextDisabled,
            letterSpacing = (0.08).sp
        )
    }
}

// ═══════════════════════════════════════════════════════════
// DigitDots — PIN entry dots with shake
// ═══════════════════════════════════════════════════════════

@Composable
private fun DigitDots(
    buffer: List<Int>,
    maxDigits: Int,
    isError: Boolean,
    isLocked: Boolean
) {
    val shake by animateFloatAsState(
        targetValue = if (isError) 1f else 0f,
        animationSpec = if (isError) tween(LockAnimations.ErrorShakeMS)
        else tween(0),
        label = "digitShake"
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.graphicsLayer {
            translationX = if (isError)
                shake * sin(shake * 6f * PI.toFloat()) * 8f
            else 0f
        }
    ) {
        repeat(maxDigits) { i ->
            val filled = i < buffer.size
            Box(
                Modifier
                    .size(if (filled) 12.dp else 10.dp)
                    .background(
                        when {
                            isLocked -> LockTokens.LightGray
                            isError -> LockTokens.SwissRed
                            filled -> LockTokens.SwissRed
                            else -> LockTokens.LightGray
                        },
                        CircleShape
                    )
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════
// DialPadGrid — 3x4 digit pad
// ═══════════════════════════════════════════════════════════

@Composable
private fun DialPadGrid(
    onDigitTap: (Int) -> Unit,
    onBackspace: () -> Unit,
    locked: Boolean
) {
    val rows = listOf(
        listOf(1, 2, 3),
        listOf(4, 5, 6),
        listOf(7, 8, 9),
        listOf(-1, 0, -2)  // -1 spacer, -2 backspace
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(LockTokens.SM.dp)
    ) {
        for (row in rows) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(LockTokens.SM.dp)
            ) {
                for (d in row) {
                    when (d) {
                        -1 -> Box(Modifier.size(64.dp)) // spacer
                        -2 -> BackspaceButton(enabled = !locked, onClick = onBackspace)
                        else -> DialButton(
                            digit = d,
                            locked = locked,
                            onTap = { onDigitTap(d) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DialButton(
    digit: Int,
    locked: Boolean,
    onTap: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val isPressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = tween(LockAnimations.HolePressMS),
        label = "dialPress"
    )

    Box(
        Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(
                if (locked) LockTokens.Sunken
                else if (isPressed) LockTokens.SwissRed.copy(0.08f)
                else LockTokens.White,
                CircleShape
            )
            .border(
                width = 1.dp,
                color = if (locked) LockTokens.LightGray
                else LockTokens.SwissRed.copy(0.2f),
                shape = CircleShape
            )
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = !locked,
                onClick = onTap
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            digit.toString(),
            fontSize = 22.sp,
            fontWeight = FontWeight.Medium,
            color = if (locked) LockTokens.TextDisabled
            else LockTokens.TextPrimary
        )
    }
}

@Composable
private fun BackspaceButton(
    enabled: Boolean,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val isPressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = tween(LockAnimations.HolePressMS),
        label = "backspaceScale"
    )

    Box(
        Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(
                if (isPressed) LockTokens.SwissRed.copy(0.08f)
                else LockTokens.White,
                CircleShape
            )
            .border(
                width = 1.dp,
                color = LockTokens.SwissRed.copy(0.2f),
                shape = CircleShape
            )
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "\u232B",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = if (enabled) LockTokens.SwissRed
            else LockTokens.TextDisabled
        )
    }
}

// ═══════════════════════════════════════════════════════════
// PatternGridView — 3x3 grid for pattern lock
// ═══════════════════════════════════════════════════════════

@Composable
private fun PatternGridView(
    nodes: List<Int>,
    isLocked: Boolean,
    isError: Boolean,
    onNodeSelected: (Int) -> Unit,
    onCancel: () -> Unit
) {
    val nodeColor = when {
        isLocked -> LockTokens.LightGray
        isError -> LockTokens.SwissRed
        else -> LockTokens.SwissRed
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(160.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                if (nodes.size > 1) {
                    val positions = getNodePositions(size, 3)
                    for (i in 0 until nodes.lastIndex) {
                        val fromNode = nodes[i]
                        val toNode = nodes[i + 1]
                        positions[fromNode]?.let { fromPos ->
                            positions[toNode]?.let { toPos ->
                                drawLine(
                                    color = nodeColor,
                                    start = fromPos,
                                    end = toPos,
                                    strokeWidth = 3f,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(LockTokens.LG.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                for (row in 0 until 3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(LockTokens.LG.dp)) {
                        for (col in 0 until 3) {
                            val idx = row * 3 + col
                            val isActive = idx in nodes
                            PatternNodeView(
                                active = isActive,
                                locked = isLocked,
                                error = isError,
                                onTap = { if (!isLocked && !isActive) onNodeSelected(idx) }
                            )
                        }
                    }
                }
            }
        }

        if (nodes.isNotEmpty() && !isLocked) {
            Spacer(Modifier.height(LockTokens.SM.dp))
            Text(
                "CANCEL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (0.1).sp,
                color = LockTokens.TextDisabled,
                modifier = Modifier
                    .clip(RoundedCornerShape(LockTokens.SM.dp))
                    .clickable(onClick = onCancel)
                    .padding(LockTokens.XS.dp)
            )
        }
    }
}

@Composable
private fun PatternNodeView(
    active: Boolean,
    locked: Boolean,
    error: Boolean,
    onTap: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val isPressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.85f else if (active) 1.15f else 1f,
        animationSpec = tween(100),
        label = "nodeScale"
    )

    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(
                when {
                    locked -> LockTokens.LightGray
                    error -> LockTokens.SwissRed
                    active -> LockTokens.SwissRed
                    else -> LockTokens.White
                },
                CircleShape
            )
            .border(
                width = 1.5.dp,
                color = if (locked) LockTokens.LightGray else LockTokens.TextPrimary,
                shape = CircleShape
            )
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = !locked && !active,
                onClick = onTap
            )
    )
}

private fun getNodePositions(
    size: Size,
    cols: Int
): Map<Int, Offset> {
    val result = mutableMapOf<Int, Offset>()
    val cellW = size.width / cols
    val cellH = size.height / cols
    for (row in 0 until cols) {
        for (col in 0 until cols) {
            result[row * cols + col] = Offset(
                x = cellW * (col + 0.5f),
                y = cellH * (row + 0.5f)
            )
        }
    }
    return result
}

// ═══════════════════════════════════════════════════════════
// ErrorMessageDisplay — error with shake, lockout timer
// ═══════════════════════════════════════════════════════════

@Composable
private fun ErrorMessageDisplay(state: LockUiState) {
    val shake by animateFloatAsState(
        targetValue = if (state.lockState == LockState.Error) 1f else 0f,
        animationSpec = if (state.lockState == LockState.Error)
            tween(LockAnimations.ErrorShakeMS)
        else tween(0),
        label = "errorShake"
    )

    AnimatedVisibility(
        visible = state.errorMessage != null,
        enter = fadeIn(tween(LockAnimations.StatusFadeMS)),
        exit = fadeOut(tween(LockAnimations.StatusFadeMS))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                state.errorMessage.orEmpty(),
                color = LockTokens.SwissRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.graphicsLayer {
                    translationX = shake * sin(shake * 6f * PI.toFloat()) * 8f
                }
            )
            if (state.lockState == LockState.LockedOut && state.lockoutEndTime != null) {
                LockoutTimerText(state.lockoutEndTime)
            }
        }
    }
}

@Composable
private fun LockoutTimerText(endTime: Long) {
    var remaining by remember { mutableStateOf(0L) }

    LaunchedEffect(endTime) {
        while (true) {
            val now = System.currentTimeMillis()
            remaining = maxOf(0L, endTime - now)
            if (remaining <= 0L) break
            delay(1000)
        }
    }

    Text(
        "Try again in ${remaining / 1000}s",
        color = LockTokens.TextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium
    )
}

// ═══════════════════════════════════════════════════════════
// DnsQueriesSection — DNS query viewer
// ═══════════════════════════════════════════════════════════

@Stable
@Composable
private fun DnsQueriesSection(
    queries: List<DnsQuery>,
    liveEnabled: Boolean,
    onToggleLive: () -> Unit,
    onClearAll: () -> Unit
) {
    // Use derivedStateOf to avoid recomputing query count on every frame
    val queryCount by remember(queries) { derivedStateOf { queries.size } }

    Column(
        Modifier
            .fillMaxWidth()
            .background(LockTokens.Sunken, RoundedCornerShape(16.dp))
            .padding(LockTokens.MD.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "DNS Queries ($queryCount)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = LockTokens.TextPrimary,
                letterSpacing = (-0.1).sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(LockTokens.XS.dp)) {
                // Live toggle
                Box(
                    Modifier
                        .clip(CircleShape)
                        .size(28.dp)
                        .background(
                            if (liveEnabled) LockTokens.SwissRed.copy(0.15f)
                            else LockTokens.White
                        ).clickable(onClick = onToggleLive),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (liveEnabled) Icons.Rounded.Pause
                        else Icons.Rounded.PlayArrow,
                        contentDescription = "Toggle live capture",
                        tint = if (liveEnabled) LockTokens.SwissRed
                            else LockTokens.TextDisabled,
                        modifier = Modifier.size(14.dp)
                    )
                }
                // Clear all
                Box(
                    Modifier
                        .clip(CircleShape)
                        .size(28.dp)
                        .background(LockTokens.White)
					.clickable(onClick = onClearAll),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.DeleteOutline,
                        contentDescription = "Clear all queries",
                        tint = LockTokens.TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(LockTokens.XS.dp))

        if (queries.isEmpty()) {
            Text(
                "No queries yet",
                fontSize = 11.sp,
                color = LockTokens.TextDisabled,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
            )
        } else {
            val listState = rememberLazyListState()
            LazyColumn(
                state = listState,
                modifier = Modifier.heightIn(max = 160.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                items(
                    items = queries,
                    key = { query -> query.id },
                    contentType = { "dns_query_row" }
                ) { query ->
                    DnsQueryRow(query)
                }
            }
        }
    }
}

@Stable
@Composable
private fun DnsQueryRow(query: DnsQuery) {
	// Pre-compute values to avoid recomputation during recomposition
	val statusColor = if (query.blocked) LockTokens.SwissRed else LockTokens.SwissGreen
	val statusText = if (query.blocked) "BLOCKED" else "ALLOWED"
	val statusBackground = if (query.blocked) LockTokens.SwissRed.copy(0.1f) else LockTokens.SwissGreen.copy(0.1f)
	val domainColor = if (query.blocked) LockTokens.SwissRed else LockTokens.TextPrimary
    Row(
        Modifier
            .fillMaxWidth()
            .background(LockTokens.White, RoundedCornerShape(8.dp))
            .padding(horizontal = LockTokens.SM.dp, vertical = LockTokens.XS.dp),
        horizontalArrangement = Arrangement.spacedBy(LockTokens.XS.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .background(
                    if (query.blocked) LockTokens.SwissRed else LockTokens.SwissGreen,
                    CircleShape
                )
        )

        Column(Modifier.weight(1f)) {
            Text(
                query.domain,
                fontSize = 11.sp,
                maxLines = 1,
                fontWeight = FontWeight.Medium,
                color = if (query.blocked) LockTokens.SwissRed
                    else LockTokens.TextPrimary,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                query.timestamp.toTimeStr(),
                fontSize = 9.sp,
                color = LockTokens.TextDisabled
            )
        }

        Text(
            if (query.blocked) "BLOCKED" else "ALLOWED",
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = if (query.blocked) LockTokens.SwissRed
                else LockTokens.SwissGreen,
            modifier = Modifier
                .background(
                    if (query.blocked) LockTokens.SwissRed.copy(0.1f)
                    else LockTokens.SwissGreen.copy(0.1f),
                    RoundedCornerShape(4.dp)
                )
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
    Box(Modifier.fillMaxWidth().height(0.5.dp).background(LockTokens.Sunken))
}

private fun Long.toTimeStr(): String {
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = this
    val h = cal.get(java.util.Calendar.HOUR_OF_DAY)
    val m = cal.get(java.util.Calendar.MINUTE)
    val s = cal.get(java.util.Calendar.SECOND)
    return String.format(java.util.Locale.getDefault(), "%02d:%02d:%02d", h, m, s)
}
