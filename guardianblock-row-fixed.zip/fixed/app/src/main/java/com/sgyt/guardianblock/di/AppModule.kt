package com.sgyt.guardianblock.di

import android.content.Context
import com.sgyt.guardianblock.data.repository.BlockRepositoryImpl
import com.sgyt.guardianblock.domain.repository.BlockRepository
import com.sgyt.guardianblock.ui.theme.ThemeManager
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AppModule {
    @Binds
    @Singleton
    abstract fun bindBlockRepository(impl: BlockRepositoryImpl): BlockRepository

    companion object {
        @Provides
        @Singleton
        fun provideThemeManager(@ApplicationContext context: Context): ThemeManager {
            return ThemeManager(context)
        }
    }
}
