package com.sgyt.guardianblock.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.sgyt.guardianblock.MainActivity

/**
 * Triggered by *#*#7467#*#* in the phone dialer.
 *
 * Android 10+ (API 29) blocks startActivity() from BroadcastReceiver.onReceive()
 * when the app is in the background. The only reliable cross-version solution
 * is to post a high-priority heads-up notification with a PendingIntent.
 * The user taps it once and the app opens - one extra tap, but 100% reliable.
 *
 * On Android 9 and below we also attempt a direct launch as a fallback.
 */
class DialerReceiver : BroadcastReceiver() {

    companion object {
        private const val CHANNEL_ID      = "gb_launch_channel"
        private const val NOTIFICATION_ID = 9001
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SECRET_CODE") return
        if (intent.data?.host != "7467") return

        // Enable alias so explicit launch resolves correctly
        val alias = ComponentName(context, "com.sgyt.guardianblock.MainActivityAlias")
        context.packageManager.setComponentEnabledSetting(
            alias,
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
        }

        // Android 10+ - direct startActivity is silently blocked from background.
        // Post a heads-up notification instead; tapping it launches the app.
        ensureChannel(context)

        val pi = PendingIntent.getActivity(
            context, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("System Services")
            .setContentText("Tap to open")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SYSTEM)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true) // attempts lock-screen popup on API 29+
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notification)

        // Android 9 and below - direct launch works fine
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            try { context.startActivity(launchIntent) } catch (_: Exception) {}
        }
    }

    private fun ensureChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "System Services",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "System service notifications"
            setShowBadge(false)
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }
}
