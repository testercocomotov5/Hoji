package com.sgyt.guardianblock.ui.query

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sgyt.guardianblock.domain.model.DnsQuery
import com.sgyt.guardianblock.ui.theme.themeColors

// BUG-7 FIX: All hardcoded Color.White / Color(0xFF1A1A1A) replaced with
// themeColors() so dark-mode switch is respected.

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DnsQueryScreen(
    onNavigateBack: () -> Unit,
    viewModel: DnsQueryViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val tc     = themeColors()

    Scaffold(
        containerColor = tc.background,               // ← theme-aware
        topBar = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(tc.background)         // ← theme-aware
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(tc.surface)            // ← theme-aware
                        ) {
                            Icon(Icons.Rounded.ArrowBack, "Back",
                                tint = tc.textPrimary, modifier = Modifier.size(20.dp))
                        }
                        Column {
                            Text("DNS Queries", fontWeight = FontWeight.Bold,
                                fontSize = 20.sp, color = tc.textPrimary,
                                letterSpacing = (-0.3).sp)
                            Text("${state.queries.size} captured", fontSize = 12.sp,
                                fontWeight = FontWeight.Medium, color = tc.textDisabled)
                        }
                    }
                    if (state.queries.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = { viewModel.liveEnabled = !viewModel.liveEnabled },
                                modifier = Modifier.size(36.dp).clip(CircleShape)
                                    .background(
                                        if (viewModel.liveEnabled)
                                            Color(0xFFE30613).copy(0.1f)
                                        else tc.surface
                                    )
                            ) {
                                Icon(
                                    if (viewModel.liveEnabled) Icons.Rounded.Pause
                                    else Icons.Rounded.PlayArrow, null,
                                    tint = if (viewModel.liveEnabled) Color(0xFFE30613)
                                           else tc.textDisabled,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { viewModel.clearAll() },
                                modifier = Modifier.size(36.dp).clip(CircleShape)
                                    .background(tc.surface)
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, null,
                                    tint = tc.textSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    ) { inner ->
        if (state.queries.isEmpty()) {
            EmptyStateView(Modifier.fillMaxSize().padding(inner))
        } else {
            LazyColumn(
                state          = rememberLazyListState(),
                modifier       = Modifier.fillMaxSize().padding(inner),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                items(items = state.queries, key = { it.id }) { query ->
                    AnimatedVisibility(
                        visible = true,
                        enter   = fadeIn(tween(200)) + slideInVertically(tween(200)) { -it / 2 }
                    ) {
                        QueryRow(query) { viewModel.deleteQuery(query.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyStateView(modifier: Modifier) {
    val tc = themeColors()
    Box(modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(72.dp)
                    .background(tc.surface, CircleShape)
                    .wrapContentSize(Alignment.Center)
            ) {
                Icon(Icons.Rounded.Search, null,
                    tint = tc.textDisabled, modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("No queries captured yet", fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp, color = tc.textDisabled)
            Text("Start the DNS filter to see queries",
                fontSize = 13.sp, color = tc.textDisabled.copy(0.7f))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun QueryRow(query: DnsQuery, onDelete: () -> Unit) {
    val tc      = themeColors()
    val timeStr = formatTime(query.timestamp)

    Row(
        Modifier
            .fillMaxWidth()
            .background(tc.background)             // ← theme-aware
            .combinedClickable(onClick = {}, onLongClick = onDelete)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onDelete) {
            Icon(Icons.Rounded.Close, "Delete",
                tint = tc.border, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(8.dp))
        BlockIndicator(query.blocked)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                query.domain, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                color = if (query.blocked) Color(0xFFE30613) else tc.textPrimary,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(timeStr, fontSize = 11.sp, color = tc.textDisabled,
                fontWeight = FontWeight.Medium)
        }
        StatusLabel(query.blocked)
    }
}

@Composable
private fun BlockIndicator(blocked: Boolean) {
    Box(
        Modifier.size(10.dp).background(
            if (blocked) Color(0xFFE30613) else Color(0xFF00843D), CircleShape
        )
    )
}

@Composable
private fun StatusLabel(blocked: Boolean) {
    Text(
        if (blocked) "BLOCKED" else "ALLOWED",
        fontSize = 9.sp, fontWeight = FontWeight.Bold,
        color = if (blocked) Color(0xFFE30613) else Color(0xFF00843D),
        modifier = Modifier
            .background(
                if (blocked) Color(0xFFF2DEE0) else Color(0xFFE8F5E9),
                RoundedCornerShape(4.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

private fun formatTime(ts: Long): String {
    val cal = java.util.Calendar.getInstance().also { it.timeInMillis = ts }
    return "%02d:%02d:%02d".format(
        cal.get(java.util.Calendar.HOUR_OF_DAY),
        cal.get(java.util.Calendar.MINUTE),
        cal.get(java.util.Calendar.SECOND)
    )
}
