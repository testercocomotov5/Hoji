package com.sgyt.guardianblock.ui.lockscreen

import com.sgyt.guardianblock.domain.model.DnsQuery

/** Lock screen input methods */
enum class LockMethod { FourDigit, SixDigit, Pattern }

/** Lock screen states */
enum class LockState {
    Idle, Inputting, Validating, Success, Error, LockedOut
}

/** Immutable lock screen snapshot */
data class LockUiState(
    val method          : LockMethod  = LockMethod.FourDigit,
    val lockState       : LockState   = LockState.Idle,
    val digitBuffer     : List<Int>   = emptyList(),
    val patternNodes    : List<Int>   = emptyList(),
    val failureCount    : Int         = 0,
    val lockoutEndTime  : Long?       = null,
    val errorMessage    : String?     = null,
    val pinHash         : String      = "",
    val isAuthenticated : Boolean     = false,
    val queries         : List<DnsQuery> = emptyList(),
    val liveQueryEnabled: Boolean     = true,
) {
    val maxDigits: Int get() = when (method) {
        LockMethod.FourDigit -> LockTokens.MAX_DIGITS_4
        LockMethod.SixDigit  -> LockTokens.MAX_DIGITS_6
        LockMethod.Pattern   -> 0
    }
    val canSubmit: Boolean get() = when (method) {
        LockMethod.FourDigit -> digitBuffer.size == LockTokens.MAX_DIGITS_4
        LockMethod.SixDigit  -> digitBuffer.size == LockTokens.MAX_DIGITS_6
        LockMethod.Pattern   -> patternNodes.size >= 4
    }
}

/** All discrete events that can mutate lock state */
sealed class LockEvent {
    object AddDigit       : LockEvent()
    object RemoveDigit    : LockEvent()
    object SelectPatternNode : LockEvent()
    object CancelPattern  : LockEvent()
    object Submit         : LockEvent()
    object AuthSuccess    : LockEvent()
    data class AuthFailure(val error: String) : LockEvent()
    object DismissError   : LockEvent()
    data class ChangeMethod(val method: LockMethod) : LockEvent()
    object LockoutEnded   : LockEvent()

    // DNS query events
    object DnsCheckStarted : LockEvent()
    data class DnsCheckSuccess(val result: String) : LockEvent()
    data class DnsCheckFailure(val error: String) : LockEvent()
    data class DnsQueryCaptured(val query: DnsQuery) : LockEvent()
}
