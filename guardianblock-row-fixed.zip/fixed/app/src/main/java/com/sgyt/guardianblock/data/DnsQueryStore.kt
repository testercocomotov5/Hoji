package com.sgyt.guardianblock.data

import com.sgyt.guardianblock.data.local.AppDatabase
import com.sgyt.guardianblock.data.local.DnsQueryEntity
import com.sgyt.guardianblock.domain.model.DnsQuery
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DnsQueryStore @Inject constructor(
    private val database: AppDatabase
) {

    private val dao get() = database.dnsQueryDao()

    /**
     * Get all DNS queries as a Flow for live updates
     */
    val queries: Flow<List<DnsQuery>> = dao.getAllQueries().map { entities ->
        entities.map { it.toDomainModel() }
    }

    /**
     * Add a new DNS query to the database
     */
    suspend fun add(domain: String, blocked: Boolean) {
        val entity = DnsQueryEntity(
            domain = domain,
            blocked = blocked,
            timestamp = System.currentTimeMillis()
        )
        dao.insertQuery(entity)
    }

    /**
     * Delete all queries older than the specified timestamp
     * Note: Individual deletion by ID is not implemented in DAO,
     * using deleteOlderThan for cleanup instead
     */
    suspend fun deleteQuery(id: Long) {
        dao.deleteById(id)
    }

    /**
     * Clear all DNS queries from the database
     */
    suspend fun clearAll() {
        dao.deleteAll()
    }

    /**
     * Clean up old queries to prevent unbounded growth
     * @param olderThan Timestamp in milliseconds - queries older than this will be deleted
     */
    suspend fun cleanupOldQueries(olderThan: Long) {
        dao.deleteOlderThan(olderThan)
    }

    /**
     * Get count of blocked queries
     */
    fun getBlockedCount(): Flow<Int> = dao.getBlockedCount()

    /**
     * Get total query count
     */
    fun getTotalCount(): Flow<Int> = dao.getTotalCount()

    /**
     * Get only blocked queries
     */
    fun getBlockedQueries(): Flow<List<DnsQuery>> = dao.getBlockedQueries().map { entities ->
        entities.map { it.toDomainModel() }
    }

    /**
     * Get only allowed queries
     */
    fun getAllowedQueries(): Flow<List<DnsQuery>> = dao.getAllowedQueries().map { entities ->
        entities.map { it.toDomainModel() }
    }

    /**
     * Extension function to convert entity to domain model
     */
    private fun DnsQueryEntity.toDomainModel(): DnsQuery {
        return DnsQuery(
            id = id,
            domain = domain,
            timestamp = timestamp,
            blocked = blocked,
            queryType = "A"
        )
    }
}
