package com.sgyt.guardianblock.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sgyt.guardianblock.domain.model.BlockConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences>
        by preferencesDataStore(name = "guardian_prefs")

@Singleton
class PreferencesManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val KEY_DNS_ENABLED = booleanPreferencesKey("dns_enabled")
    private val KEY_PIN_HASH    = stringPreferencesKey("pin_hash")
    private val KEY_CUSTOM_KW   = stringSetPreferencesKey("custom_keywords")

    private fun kwEnabledKey(k: String) = booleanPreferencesKey("kw_$k")

    fun getBlockConfig(): Flow<BlockConfig> = context.dataStore.data.map { prefs ->
        val customKws   = prefs[KEY_CUSTOM_KW] ?: emptySet()
        val allKeywords = (BlockConfig.defaultKeywords().keys + customKws)
            .associateWith { kw -> prefs[kwEnabledKey(kw)] ?: true }
            .let { map -> linkedMapOf<String, Boolean>().also { it.putAll(map) } }

        BlockConfig(
            isDnsEnabled = prefs[KEY_DNS_ENABLED] ?: true,
            keywords     = allKeywords,
            pinHash      = prefs[KEY_PIN_HASH] ?: ""
        )
    }

    suspend fun saveBlockConfig(config: BlockConfig) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DNS_ENABLED] = config.isDnsEnabled
            config.keywords.forEach { (kw, enabled) -> prefs[kwEnabledKey(kw)] = enabled }
        }
    }

    suspend fun addKeyword(keyword: String) {
        val clean = keyword.trim().lowercase()
        if (clean.isEmpty()) return
        context.dataStore.edit { prefs ->
            val existing = prefs[KEY_CUSTOM_KW] ?: emptySet()
            prefs[KEY_CUSTOM_KW] = existing + clean
            prefs[kwEnabledKey(clean)] = true
        }
    }

    suspend fun removeKeyword(keyword: String) {
        if (keyword in BlockConfig.PROTECTED_KEYWORDS) return
        if (keyword in BlockConfig.defaultKeywords().keys) {
            // Default keywords can't be truly deleted — just disable them
            context.dataStore.edit { prefs -> prefs[kwEnabledKey(keyword)] = false }
            return
        }
        // BUG-J FIX: also remove the per-keyword enabled flag when deleting a custom keyword.
        // Previously, only KEY_CUSTOM_KW was updated.  The orphaned kw_<keyword> boolean
        // entry would accumulate in the DataStore indefinitely and could ghost-enable a
        // keyword if it was ever re-added with the same name.
        context.dataStore.edit { prefs ->
            val existing = prefs[KEY_CUSTOM_KW] ?: emptySet()
            prefs[KEY_CUSTOM_KW] = existing - keyword
            prefs.remove(kwEnabledKey(keyword))   // clean up the per-keyword flag
        }
    }

    suspend fun getPinHash(): String =
        context.dataStore.data.first()[KEY_PIN_HASH] ?: ""

    suspend fun savePinHash(hash: String) {
        context.dataStore.edit { prefs -> prefs[KEY_PIN_HASH] = hash }
    }
}
