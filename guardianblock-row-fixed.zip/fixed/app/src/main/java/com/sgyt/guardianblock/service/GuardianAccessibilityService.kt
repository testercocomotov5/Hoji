package com.sgyt.guardianblock.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * GuardianAccessibilityService
 *
 * Three responsibilities:
 *   1. Block device-admin removal (auto-clicks Cancel in the Settings deactivation dialog)
 *   2. Auto-dismiss our own persistent notification from the notification shade
 *   3. Auto-grant the VPN permission dialog (clicks OK/Allow)
 *
 * Bug fix in v9:
 *
 *   [BUG-N FIX] findAndClickButton previously returned Unit.  When a matching button was
 *               found and clicked, the recursive for-loop in the PARENT call frame continued
 *               iterating remaining siblings and could click additional unintended buttons
 *               (e.g., clicking the VPN "Allow" button AND then a subsequent dialog button).
 *               The fix changes the return type to Boolean.  A true return short-circuits
 *               the loop so traversal stops the moment a target is clicked.
 */
class GuardianAccessibilityService : AccessibilityService() {

    companion object {
        private const val OUR_PACKAGE = "com.sgyt.guardianblock"

        private val SETTINGS_PACKAGES = setOf(
            "com.android.settings",
            "com.samsung.android.settings",
            "com.miui.securitycenter",
            "com.oneplus.settings",
            "com.coloros.settings",
            "com.oppo.settings"
        )

        private val VPN_DIALOG_PACKAGES = setOf(
            "android",
            "com.android.systemui",
            "com.android.settings"
        )

        private val VPN_POSITIVE = setOf("ok", "okay", "connect", "allow", "yes", "accept", "continue")

        private val ADMIN_NEGATIVE = setOf(
            "cancel", "no", "disagree", "decline", "back", "deactivate and uninstall"
        )

        private val ADMIN_POSITIVE_DANGER = setOf(
            "deactivate", "disable", "remove", "ok", "yes", "confirm"
        )

        private val ADMIN_DIALOG_TITLE_HINTS = setOf(
            "deactivate", "device admin", "remove admin",
            "disable", "device manager", "admin app"
        )

        fun isEnabled(context: Context): Boolean {
            val expectedComponent =
                ComponentName(context, GuardianAccessibilityService::class.java).flattenToString()
            val enabled = android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.split(":").any { it.equals(expectedComponent, ignoreCase = true) }
        }
    }

    override fun onServiceConnected() {
        serviceInfo = serviceInfo?.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                         AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
            feedbackType        = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
        minimiseOurNotification()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                when {
                    pkg in SETTINGS_PACKAGES   -> handleSettingsWindow(event)
                    pkg in VPN_DIALOG_PACKAGES -> tryAutoGrantVpnDialog()
                }
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                tryDismissOurNotification()
            }
        }
    }

    // ── Device admin removal blocking ─────────────────────────────────────────

    private fun handleSettingsWindow(event: AccessibilityEvent) {
        val title = event.text?.joinToString(" ")?.lowercase() ?: ""
        val isAdminDialog = ADMIN_DIALOG_TITLE_HINTS.any { hint -> title.contains(hint) }
        if (!isAdminDialog) return

        val root = rootInActiveWindow ?: return
        blockAdminRemoval(root)
        root.recycle()
    }

    private fun blockAdminRemoval(root: AccessibilityNodeInfo) {
        val buttons = mutableListOf<AccessibilityNodeInfo>()
        collectButtons(root, buttons)

        val dangerButton = buttons.firstOrNull { btn ->
            val text = btn.text?.toString()?.trim()?.lowercase() ?: ""
            text in ADMIN_POSITIVE_DANGER
        }

        if (dangerButton != null) {
            val cancelButton = buttons.firstOrNull { btn ->
                val text = btn.text?.toString()?.trim()?.lowercase() ?: ""
                text in ADMIN_NEGATIVE
            }
            if (cancelButton != null) {
                cancelButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }

        buttons.forEach { it.recycle() }
    }

    private fun collectButtons(node: AccessibilityNodeInfo, result: MutableList<AccessibilityNodeInfo>) {
        val isButton = node.isClickable &&
                (node.className?.contains("Button", ignoreCase = true) == true ||
                 node.className?.contains("TextView", ignoreCase = true) == true)
        if (isButton && !node.text.isNullOrEmpty()) {
            result.add(node)
            // Don't recurse into children of a kept button — avoids double-adding nested views
            return
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectButtons(child, result)
            // child is recycled later by buttons.forEach { it.recycle() } if it was added,
            // or here if it wasn't added (i.e., not a button leaf we want to keep).
            if (child !in result) child.recycle()
        }
    }

    // ── VPN dialog auto-grant ─────────────────────────────────────────────────

    private fun tryAutoGrantVpnDialog() {
        val root = rootInActiveWindow ?: return
        findAndClickButton(root, VPN_POSITIVE)
        root.recycle()
    }

    // ── Notification auto-dismiss ─────────────────────────────────────────────

    private fun tryDismissOurNotification() {
        for (window in windows ?: return) {
            val root = window.root ?: continue
            dismissNotificationNodes(root)
            root.recycle()
        }
    }

    private fun dismissNotificationNodes(node: AccessibilityNodeInfo) {
        val desc   = node.contentDescription?.toString() ?: ""
        val viewId = node.viewIdResourceName ?: ""
        if (OUR_PACKAGE in desc || OUR_PACKAGE in viewId) {
            val ok = node.performAction(AccessibilityNodeInfo.ACTION_DISMISS)
            if (!ok && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLEAR_ACCESSIBILITY_FOCUS)
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            dismissNotificationNodes(child)
            child.recycle()
        }
    }

    // ── Shared button finder ──────────────────────────────────────────────────

    /**
     * Depth-first search for a clickable Button whose text matches [targets].
     * Returns true if a button was clicked so the caller can stop traversal immediately.
     *
     * BUG-N FIX: The old version returned Unit and the for-loop in every call frame
     * continued iterating siblings even after a button had been clicked.  This could
     * trigger multiple unintended clicks in the same dialog window.  The Boolean return
     * value short-circuits the loop the moment a target is found and clicked.
     */
    private fun findAndClickButton(node: AccessibilityNodeInfo, targets: Set<String>): Boolean {
        if (node.isClickable &&
            node.className?.contains("Button", ignoreCase = true) == true) {
            val text = node.text?.toString()?.trim()?.lowercase()
            if (text != null && text in targets) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true   // signal: stop traversal
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val clicked = findAndClickButton(child, targets)
            child.recycle()
            if (clicked) return true   // BUG-N FIX: propagate stop signal up the call stack
        }
        return false
    }

    // ── Notification importance ───────────────────────────────────────────────

    private fun minimiseOurNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = nm.getNotificationChannel(PrivateDnsService.CHANNEL_ID) ?: return
        if (channel.importance > NotificationManager.IMPORTANCE_MIN) {
            channel.importance = NotificationManager.IMPORTANCE_MIN
            nm.createNotificationChannel(channel)
        }
    }

    override fun onInterrupt() {}
}
