package com.sgyt.guardianblock

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.sgyt.guardianblock.ui.lockscreen.RotaryLockscreenActivity
import com.sgyt.guardianblock.ui.navigation.AppNavigation
import com.sgyt.guardianblock.ui.theme.GuardianBlockTheme
import com.sgyt.guardianblock.ui.theme.ThemeManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * FUSION: MainActivity now launches RotaryLockscreenActivity for a result.
 * The Compose UI (AppNavigation starting at Dashboard) is only shown after
 * the lockscreen delivers RESULT_OK.
 *
 * If no passcode is configured yet, the lockscreen activity self-finishes
 * with RESULT_OK so the user reaches the dashboard immediately (where they
 * can set a PIN in Settings).
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var themeManager: ThemeManager

    private val lockscreenLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                showMainContent()
            } else {
                // Lockscreen dismissed/failed — stay on lockscreen (re-launch).
                launchLockscreen()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        launchLockscreen()
    }

    private fun launchLockscreen() {
        lockscreenLauncher.launch(Intent(this, RotaryLockscreenActivity::class.java))
    }

    private fun showMainContent() {
        setContent {
            val appTheme by themeManager.appTheme.collectAsState(initial = ThemeManager.DEFAULT_THEME)
            GuardianBlockTheme(theme = appTheme) {
                AppNavigation()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Keep the stealth alias always disabled while the app is on-screen.
        val alias = ComponentName(this, "com.sgyt.guardianblock.MainActivityAlias")
        packageManager.setComponentEnabledSetting(
            alias,
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
