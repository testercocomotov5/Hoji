package com.sgyt.guardianblock.view

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.animation.doOnEnd
import kotlin.math.*

// BUG-6 FIX: Color(0xFFxxxxxx) where the hex literal exceeds Int.MAX_VALUE is
// a Long in Kotlin, which calls android.graphics.Color(long) and returns a
// Color *object* — not an Int.  RadialGradient(…, Int, Int, …) expects plain
// Int ARGB values (works down to minSdk 26), not Color objects.
// Fix: use explicit .toInt() so the literal stays an Int ARGB.

class RotaryDialView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface OnNumberSelectedListener {
        fun onNumberSelected(number: Int)
    }

    var onNumberSelectedListener: OnNumberSelectedListener? = null

    private val numbers = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
    var maxDigits: Int = 4

    // Paints
    private val dialPlatePaint      = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outerShadowPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val numberHolePaint     = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val numberTextPaint     = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val centerHubPaint      = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val fingerStopPaint     = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    // State
    private var currentRotation = 0f
    private var isDragging = false
    private var startAngle = 0f
    private var isReturning = false
    private var selectedNumber: Int? = null

    // Dimensions
    private var centerX = 0f
    private var centerY = 0f
    private var dialRadius = 0f
    private var numberRadius = 0f
    private var numberHoleRadius = 0f

    // Animation
    private var returnAnimator: ValueAnimator? = null

    // BUG-6 FIX: explicit .toInt() converts the unsigned hex literal to a
    // signed Int ARGB so it is compatible with all Paint/Shader/RadialGradient
    // overloads available from minSdk 26.
    private val creamColor        = 0xFFFFFFFF.toInt()
    private val beigeColor        = 0xFFEBEBEB.toInt()
    private val darkBeigeColor    = 0xFFCCCCCC.toInt()
    private val darkerBeigeColor  = 0xFFAAAAAA.toInt()
    private val textColor         = 0xFF1A1A1A.toInt()
    private val highlightColor    = 0xFFE30613.toInt()
    private val fingerStopColor   = 0xFFE30613.toInt()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        centerX = w / 2f
        centerY = h / 2f
        dialRadius = min(w, h) / 2f - 40f
        numberRadius = dialRadius * 0.68f
        numberHoleRadius = dialRadius * 0.13f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.save()
        canvas.rotate(currentRotation, centerX, centerY)

        drawOuterShadow(canvas)
        drawDialPlate(canvas)
        drawNumberHoles(canvas)

        canvas.restore()

        drawCenterHub(canvas)
        drawFingerStop(canvas)
    }

    private fun drawOuterShadow(canvas: Canvas) {
        val shadowGradient = RadialGradient(
            centerX, centerY, dialRadius,
            intArrayOf(0x10000000, 0x05000000, Color.TRANSPARENT),
            floatArrayOf(0.7f, 0.9f, 1f),
            Shader.TileMode.CLAMP
        )
        outerShadowPaint.shader = shadowGradient
        outerShadowPaint.setShadowLayer(30f, 0f, 15f, 0x26000000)
        canvas.drawCircle(centerX, centerY, dialRadius, outerShadowPaint)
    }

    private fun drawDialPlate(canvas: Canvas) {
        val plateGradient = RadialGradient(
            centerX, centerY - dialRadius * 0.3f, dialRadius,
            creamColor, beigeColor,
            Shader.TileMode.CLAMP
        )
        dialPlatePaint.shader = plateGradient
        dialPlatePaint.setShadowLayer(8f, 0f, 4f, 0x1F000000)
        canvas.drawCircle(centerX, centerY, dialRadius * 0.875f, dialPlatePaint)
    }

    private fun drawNumberHoles(canvas: Canvas) {
        numbers.forEachIndexed { index, number ->
            val angle = Math.toRadians((index * 36 - 54).toDouble())
            val x = centerX + cos(angle).toFloat() * numberRadius
            val y = centerY + sin(angle).toFloat() * numberRadius

            val isHighlighted = isNumberHighlighted(index)
            val isSelected = selectedNumber == number

            val holeCenterColor = when {
                isSelected    -> highlightColor
                isHighlighted -> darkerBeigeColor
                else          -> darkBeigeColor
            }
            val holeEdgeColor = when {
                isSelected    -> 0xFF6B5344.toInt()
                isHighlighted -> 0xFFB5B0A5.toInt()
                else          -> darkerBeigeColor
            }

            val holeGradient = RadialGradient(
                x - numberHoleRadius * 0.2f,
                y - numberHoleRadius * 0.2f,
                numberHoleRadius,
                holeCenterColor, holeEdgeColor,
                Shader.TileMode.CLAMP
            )
            numberHolePaint.shader = holeGradient
            numberHolePaint.setShadowLayer(4f, 1f, 2f, 0x40000000)
            canvas.drawCircle(x, y, numberHoleRadius, numberHolePaint)

            numberTextPaint.color = if (isSelected) creamColor else textColor
            numberTextPaint.textSize = numberHoleRadius * 0.9f
            numberTextPaint.setShadowLayer(
                if (isSelected) 2f else 1f,
                0f, 1f,
                if (isSelected) 0x50000000 else 0x80FFFFFF.toInt()
            )
            canvas.drawText(number.toString(), x, y + numberTextPaint.textSize * 0.35f, numberTextPaint)
        }
    }

    private fun isNumberHighlighted(index: Int): Boolean {
        if (!isDragging || isReturning) return false
        val currentIndex = (currentRotation / 36).roundToInt()
        return currentIndex == index && currentRotation > 10f
    }

    private fun drawCenterHub(canvas: Canvas) {
        val hubGradient = RadialGradient(
            centerX - dialRadius * 0.1f,
            centerY - dialRadius * 0.1f,
            dialRadius * 0.18f,
            creamColor, beigeColor,
            Shader.TileMode.CLAMP
        )
        centerHubPaint.shader = hubGradient
        centerHubPaint.setShadowLayer(12f, 0f, 6f, 0x26000000)
        canvas.drawCircle(centerX, centerY, dialRadius * 0.18f, centerHubPaint)
    }

    private fun drawFingerStop(canvas: Canvas) {
        val stopX = centerX + dialRadius * 0.78f
        val stopWidth = dialRadius * 0.025f
        val stopHeight = dialRadius * 0.14f

        fingerStopPaint.color = fingerStopColor
        fingerStopPaint.setShadowLayer(4f, 2f, 0f, 0x40000000)

        val rect = RectF(
            stopX - stopWidth / 2,
            centerY - stopHeight / 2,
            stopX + stopWidth / 2,
            centerY + stopHeight / 2
        )
        canvas.drawRoundRect(rect, stopWidth / 2, stopWidth / 2, fingerStopPaint)

        val path = Path().apply {
            moveTo(stopX - stopWidth * 0.8f, centerY + stopHeight / 2)
            lineTo(stopX + stopWidth * 0.8f, centerY + stopHeight / 2)
            lineTo(stopX, centerY + stopHeight / 2 + stopWidth * 1.2f)
            close()
        }
        canvas.drawPath(path, fingerStopPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (isReturning) return false
                isDragging = true
                startAngle = getAngle(event.x, event.y) - currentRotation
                parent.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!isDragging || isReturning) return false
                var angle = getAngle(event.x, event.y) - startAngle
                if (angle < 0) angle += 360f
                if (angle > 330f) angle = 330f
                currentRotation = angle
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!isDragging) return false
                isDragging = false
                val numberIndex = (currentRotation / 36).roundToInt()
                if (numberIndex in 0..9) {
                    selectedNumber = numbers[numberIndex]
                    selectedNumber?.let { onNumberSelectedListener?.onNumberSelected(it) }
                }
                animateReturn()
                parent.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun getAngle(x: Float, y: Float): Float =
        Math.toDegrees(atan2((y - centerY).toDouble(), (x - centerX).toDouble())).toFloat()

    private fun animateReturn() {
        isReturning = true
        returnAnimator?.cancel()
        returnAnimator = ValueAnimator.ofFloat(currentRotation, 0f).apply {
            duration = 400
            interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener {
                currentRotation = it.animatedValue as Float
                invalidate()
            }
            doOnEnd {
                isReturning = false
                selectedNumber = null
                invalidate()
            }
            start()
        }
    }

    fun reset() {
        returnAnimator?.cancel()
        currentRotation = 0f
        selectedNumber = null
        isDragging = false
        isReturning = false
        invalidate()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        returnAnimator?.cancel()
    }
}
