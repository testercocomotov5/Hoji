package com.sgyt.guardianblock.ui.lockscreen

import androidx.compose.ui.graphics.Color

/** Design tokens — single source of truth for all visual values.
 *  Every color/spacing in lock-screen components derives from here. */
object LockTokens {

    // ── Colors ────────────────────────────────────────────────
    val White        = Color(0xFFFFFFFF)
    val OffWhite     = Color(0xFFF7F7F7)
    val Sunken       = Color(0xFFEBEBEB)
    val LightGray    = Color(0xFFCCCCCC)
    val MidGray      = Color(0xFFAAAAAA)
    val DarkCharcoal = Color(0xFF1A1A1A)
    val TextPrimary  = Color(0xFF1A1A1A)
    val TextSecondary= Color(0xFF4A4A4A)
    val TextDisabled = Color(0xFFABABAB)
    val StrokeHeavy  = Color(0xFF0A0A0A)
    val StrokeMedium = Color(0xFF2E2E2E)
    val StrokeLight  = Color(0xFFCCCCCC)
    val SwissRed     = Color(0xFFE30613)
    val SwissGreen   = Color(0xFF00843D)

    // ── Spacing (8px base grid) ─────────────────────────────
    val XS  = 4
    val SM  = 8
    val MD  = 16
    val LG  = 24
    val XL  = 32
    val XXL = 48
    val XXXL= 64

    // ── Touch target minimum (WCAG 2.5.5) ───────────────────
    val MinTouchTarget = 48

    // ── Constants ────────────────────────────────────────────
    const val MAX_FAILURES = 5
    const val LOCKOUT_MS   = 30_000L
    const val MAX_DIGITS_4 = 4
    const val MAX_DIGITS_6 = 6
    const val MAX_DNS_QUERIES = 500
}
