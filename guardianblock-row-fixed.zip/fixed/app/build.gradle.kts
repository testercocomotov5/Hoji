plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
}

android {
    namespace  = "com.sgyt.guardianblock"
    compileSdk = 34

    // BUG-2 FIX: signingConfig block only reads keystore when the file exists,
    // so CI debug builds never crash even without a release keystore.
    signingConfigs {
        create("release") {
            val keystoreFile = file("keystore/release.keystore")
            if (keystoreFile.exists()) {
                storeFile    = keystoreFile
                storePassword = "guardian2024"
                keyAlias      = "guardianblock"
                keyPassword   = "guardian2024"
            }
        }
    }

    defaultConfig {
        applicationId = "com.sgyt.guardianblock"
        minSdk        = 26
        targetSdk     = 34
        versionCode   = 1
        versionName   = "1.0"
    }

    buildTypes {
        debug {
            // No signingConfig — uses default debug keystore automatically.
        }
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Only apply release signingConfig when keystore is present.
            val keystoreFile = file("keystore/release.keystore")
            if (keystoreFile.exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }
}

dependencies {
    implementation(libs.core.ktx)
    implementation(libs.appcompat)
    implementation(libs.lifecycle.runtime)
    implementation(libs.lifecycle.viewmodel)
    implementation(libs.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons)
    implementation(libs.navigation.compose)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation)
    implementation(libs.coroutines.android)
    implementation(libs.datastore.preferences)
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    debugImplementation(libs.compose.ui.tooling)
}
