# Keep application classes
-keepattributes SourceFile,LineNumberTable
-keep class com.sgyt.guardianblock.** { *; }

# Room Database
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface * { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase { *; }
-keep class * extends androidx.room.paging.LimitOffsetDataSource
-keep class **$$Impl { *; }

# Hilt Dependency Injection
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ComponentSupplier { *; }
-keep,allowobfuscation,allowshrinking class com.sgyt.guardianblock.di.** { *; }
-keep class com.sgyt.guardianblock.**Fragment { *; }
-keep class com.sgyt.guardianblock.**Activity { *; }
-keep class com.sgyt.guardianblock.**ViewModel { *; }
-keep @dagger.hilt.android.AndroidEntryPoint class * { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }
-keepnames class * implements dagger.hilt.android.internal.managers.ComponentSupplier

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}
-keepclassmembernames class kotlinx.coroutines.flow.FlowKt { *; }
-keepclassmembernames class kotlinx.coroutines.flow.*Kt { *; }
-keepclassmembers class kotlinx.coroutines.flow.internal.FlowArithmeticKt { *; }
-keep class kotlinx.coroutines.channels.** { *; }
-keepclassmembers class kotlinx.coroutines.channels.*Kt { *; }

# Kotlin Serialization
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.sgyt.guardianblock.**$$serializer { *; }
-keepclassmembers class com.sgyt.guardianblock.** {
    *** Companion;
}
-keepclasseswithmembers class com.sgyt.guardianblock.** {
    kotlinx.serialization.KSerializer serializer(...);
}
