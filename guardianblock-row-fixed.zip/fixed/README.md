# GuardianBlock 🛡️

Android parental control app that blocks Indian gambling and betting websites using a local VPN DNS interceptor.

## Features

- **Always-on blocking** — VPN starts automatically on first launch and after every reboot
- **Keyword-based DNS blocking** — blocks domains containing: `book`, `reddy`, `club`, `daman`, `tiranga`, `bet`, `play`, `exchange`, `exch`, `11x`
- **PIN protection** — 4-digit PIN (SHA-256) locks the app from minors
- **Hide app icon** — removes the launcher icon so minors can't find it
- **Secret restore code** — dial `*#*#7467#*#*` in your phone dialer to restore the icon

---

## Build on GitLab CI (zero setup needed)

Every push automatically builds a debug APK you can download directly from GitLab.

### Step 1 — Push to GitLab

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://gitlab.com/YOUR_USERNAME/guardianblock.git
git push -u origin main
```

### Step 2 — Get the APK

1. Open your GitLab project → **Build → Pipelines**
2. Click the latest pipeline → click the `build-debug` job
3. On the right side: **Job artifacts → Download**
4. Unzip → install `app-debug.apk` on your phone

> Enable "Install from unknown sources" in your phone settings before installing.

---

## Signed Release APK (optional)

Only needed if you want a production-signed APK. Triggered by version tags.

### Step 1 — Create a keystore

```bash
keytool -genkey -v -keystore release.keystore \
  -alias guardianblock -keyalg RSA -keysize 2048 -validity 10000
```

### Step 2 — Add CI/CD Variables

Go to **GitLab project → Settings → CI/CD → Variables** and add:

| Variable | Value | Masked |
|----------|-------|--------|
| `KEYSTORE_BASE64` | `base64 -w0 release.keystore` output | ✅ Yes |
| `KEYSTORE_PASSWORD` | your keystore password | ✅ Yes |
| `KEY_ALIAS` | `guardianblock` | No |
| `KEY_PASSWORD` | your key password | ✅ Yes |

### Step 3 — Push a version tag

```bash
git tag v1.0.0
git push origin v1.0.0
```

The `build-release` job runs automatically and produces a signed APK artifact.

---

## Build locally

Requirements: Android Studio Ladybug+, JDK 17

```bash
./gradlew assembleDebug
# APK → app/build/outputs/apk/debug/app-debug.apk
```

---

## How blocking works

GuardianBlock opens a local VPN tunnel and intercepts only DNS traffic (UDP port 53).
Each DNS query domain is checked against the enabled keyword list.
Matched domains get an instant `NXDOMAIN` response — the browser never reaches the server.
All other queries are forwarded to Cloudflare `1.1.1.1`.

> ⚠️ The keyword `play` may interfere with Google Play Store. Disable it in Settings → Blocked Keywords if needed.
