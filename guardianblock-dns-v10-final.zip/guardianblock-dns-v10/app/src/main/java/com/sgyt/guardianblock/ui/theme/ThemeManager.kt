package com.sgyt.guardianblock.ui.theme

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// File-level extension — avoids JVM platform declaration clash with PreferencesManager
private val Context.themePreferencesDataStore: DataStore<Preferences>
        by preferencesDataStore(name = "theme_preferences")

class ThemeManager(private val context: Context) {

    companion object {
        private val THEME_KEY = stringPreferencesKey("app_theme")

        /** Only two Swiss themes are exposed to the user. */
        enum class AppTheme(val displayName: String) {
            SWISS_LIGHT("White"),
            SWISS_DARK("Black")
        }

        val DEFAULT_THEME = AppTheme.SWISS_LIGHT
    }

    val appTheme: Flow<AppTheme> = context.themePreferencesDataStore.data
        .map { preferences ->
            val themeName = preferences[THEME_KEY]
            try {
                themeName?.let { AppTheme.valueOf(it) } ?: DEFAULT_THEME
            } catch (e: IllegalArgumentException) {
                DEFAULT_THEME
            }
        }

    val isDarkTheme: Flow<Boolean> = appTheme.map { theme ->
        theme == AppTheme.SWISS_DARK
    }

    suspend fun setTheme(theme: AppTheme) {
        context.themePreferencesDataStore.edit { preferences ->
            preferences[THEME_KEY] = theme.name
        }
    }

    fun getThemeFromName(name: String): AppTheme {
        return try {
            AppTheme.valueOf(name)
        } catch (e: IllegalArgumentException) {
            DEFAULT_THEME
        }
    }
}
