package com.sgyt.guardianblock.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.sgyt.guardianblock.ui.theme.ThemeManager.AppTheme

// ── Swiss Light (White) ────────────────────────────────────────────────────
private val SwissLightColorScheme = lightColorScheme(
    primary            = SwissRed,
    onPrimary          = SwissWhite,
    primaryContainer   = SwissRedLight,
    onPrimaryContainer = SwissRedDark,
    secondary          = SwissDarkGray,
    onSecondary        = SwissWhite,
    secondaryContainer = SwissLightGray,
    onSecondaryContainer = SwissCharcoal,
    tertiary           = SwissBlue,
    onTertiary         = SwissWhite,
    tertiaryContainer  = SwissBlueLight,
    onTertiaryContainer = SwissBlue,
    background         = SwissWhite,
    onBackground       = SwissCharcoal,
    surface            = SwissWhite,
    onSurface          = SwissCharcoal,
    surfaceVariant     = SwissOffWhite,
    onSurfaceVariant   = SwissDarkGray,
    surfaceTint        = SwissRed,
    error              = SwissRed,
    onError            = SwissWhite,
    errorContainer     = SwissRedLight,
    onErrorContainer   = SwissRedDark,
    outline            = SwissMidGray,
    outlineVariant     = SwissLightGray
)

// ── Swiss Dark (Black) ─────────────────────────────────────────────────────
private val SwissDarkColorScheme = darkColorScheme(
    primary            = SwissRed,
    onPrimary          = SwissWhite,
    primaryContainer   = SwissRedDark,
    onPrimaryContainer = SwissRedLight,
    secondary          = SwissMidGray,
    onSecondary        = SwissCharcoal,
    secondaryContainer = SwissDarkGray,
    onSecondaryContainer = SwissLightGray,
    tertiary           = SwissBlue,
    onTertiary         = SwissWhite,
    tertiaryContainer  = Color(0xFF0D3A6E),
    onTertiaryContainer = SwissBlueLight,
    background         = SwissCharcoal,
    onBackground       = SwissWhite,
    surface            = Color(0xFF2A2A2A),
    onSurface          = SwissWhite,
    surfaceVariant     = SwissDarkGray,
    onSurfaceVariant   = SwissMidGray,
    surfaceTint        = SwissRed,
    error              = SwissRed,
    onError            = SwissWhite,
    errorContainer     = SwissRedDark,
    onErrorContainer   = SwissRedLight,
    outline            = SwissMidGray,
    outlineVariant     = SwissDarkGray
)

/** CompositionLocal carrying the active AppTheme down the tree. */
val LocalAppTheme = compositionLocalOf { AppTheme.SWISS_LIGHT }

/**
 * Semantic colour helper — call from any Composable to get theme-aware colours
 * without passing parameters.
 */
data class ThemeColors(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textDisabled: Color,
    val accent: Color,
    val success: Color,
    val border: Color,
    val borderLight: Color
)

@Composable
fun themeColors(): ThemeColors {
    val isDark = LocalAppTheme.current == AppTheme.SWISS_DARK
    return ThemeColors(
        background    = if (isDark) Color(0xFF1A1A1A) else Color.White,
        surface       = if (isDark) Color(0xFF2A2A2A) else Color(0xFFF5F5F5),
        surfaceVariant = if (isDark) Color(0xFF3A3A3A) else Color(0xFFF0F0F0),
        textPrimary   = if (isDark) Color.White       else Color(0xFF1A1A1A),
        textSecondary = if (isDark) Color(0xFFB0B0B0) else Color(0xFF666666),
        textDisabled  = if (isDark) Color(0xFF666666) else Color(0xFF999999),
        accent        = Color(0xFFE30613),  // Swiss Red — same in both themes
        success       = Color(0xFF00843D),
        border        = if (isDark) Color(0xFF3A3A3A) else Color(0xFFE0E0E0),
        borderLight   = if (isDark) Color(0xFF4A4A4A) else Color(0xFFF0F0F0)
    )
}

/**
 * GuardianBlockTheme — main entry point.
 *
 * Accepts [AppTheme] directly (injected by MainActivity via ThemeManager).
 */
@Composable
fun GuardianBlockTheme(
    theme: AppTheme = AppTheme.SWISS_LIGHT,
    content: @Composable () -> Unit
) {
    val colorScheme = when (theme) {
        AppTheme.SWISS_LIGHT -> SwissLightColorScheme
        AppTheme.SWISS_DARK  -> SwissDarkColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars =
                (theme == AppTheme.SWISS_LIGHT)
        }
    }

    CompositionLocalProvider(LocalAppTheme provides theme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = AppTypography,
            content     = content
        )
    }
}

/** No-arg overload used in legacy/preview contexts — defaults to Swiss Light. */
@Composable
fun GuardianBlockTheme(content: @Composable () -> Unit) {
    GuardianBlockTheme(theme = AppTheme.SWISS_LIGHT, content = content)
}
