package com.sgyt.guardianblock.ui.lockscreen

import android.animation.ObjectAnimator
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.sgyt.guardianblock.R
import com.sgyt.guardianblock.domain.repository.BlockRepository
import com.sgyt.guardianblock.view.RotaryDialView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

/**
 * RotaryLockscreenActivity — rotary-phone style passcode entry.
 *
 * PIN storage: uses BlockRepository (DataStore, SHA-256) — the same store as the
 * Compose lock screen — so both screens share a single PIN.
 *
 * Flow:
 *   • No PIN stored yet → deliver RESULT_OK immediately (user sets PIN in Settings).
 *   • PIN stored → show rotary dial; on match deliver RESULT_OK → MainActivity
 *     starts Compose navigation.
 *
 * Bug fixes inherited from prior versions:
 *   BUG-10: systemUiVisibility → WindowInsetsController (API 30+).
 *   BUG-11: onBackPressed() → OnBackPressedCallback.
 *   BUG-4:  dynamic clock / date text.
 *   BUG-12: ContextCompat.getDrawable().
 */
@AndroidEntryPoint
class RotaryLockscreenActivity : AppCompatActivity() {

    @Inject
    lateinit var repository: BlockRepository

    private lateinit var rotaryDialView: RotaryDialView
    private lateinit var passcodeDotsContainer: LinearLayout
    private lateinit var lockIcon: ImageView
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var statusText: TextView
    private lateinit var successOverlay: View

    private val enteredDigits = StringBuilder()
    private val dots = mutableListOf<View>()
    private var storedHash: String = ""

    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rotary_lockscreen)

        hideSystemUi()

        // Block back — the lockscreen must not be dismissable
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* intentionally empty */ }
        })

        // Read PIN hash synchronously on a background thread (DataStore first read is fast)
        storedHash = runBlocking(Dispatchers.IO) { repository.getPinHash() }

        // No PIN configured yet → pass through to dashboard where user can set one
        if (storedHash.isEmpty()) {
            setResult(Activity.RESULT_OK)
            finish()
            return
        }

        initViews()
        setupRotaryDial()
        createPasscodeDots()
        updateClock()
        handler.post(clockRunnable)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { ctrl ->
                ctrl.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                ctrl.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    private fun initViews() {
        rotaryDialView        = findViewById(R.id.rotaryDialView)
        passcodeDotsContainer = findViewById(R.id.passcodeDotsContainer)
        lockIcon              = findViewById(R.id.lockIcon)
        clockText             = findViewById(R.id.clockText)
        dateText              = findViewById(R.id.dateText)
        statusText            = findViewById(R.id.statusText)
        successOverlay        = findViewById(R.id.successOverlay)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(left = bars.left, top = bars.top,
                            right = bars.right, bottom = bars.bottom)
            insets
        }
    }

    private fun setupRotaryDial() {
        rotaryDialView.onNumberSelectedListener = object : RotaryDialView.OnNumberSelectedListener {
            override fun onNumberSelected(number: Int) { onDigitEntered(number) }
        }
    }

    private fun createPasscodeDots() {
        passcodeDotsContainer.removeAllViews()
        dots.clear()

        val dotSize   = resources.getDimensionPixelSize(R.dimen.passcode_dot_size)
        val dotMargin = resources.getDimensionPixelSize(R.dimen.passcode_dot_margin)

        repeat(4) { index ->
            val dot = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dotSize, dotSize).apply {
                    marginStart = if (index == 0) 0 else dotMargin
                    marginEnd   = if (index == 3) 0 else dotMargin
                }
                background = ContextCompat.getDrawable(
                    this@RotaryLockscreenActivity, R.drawable.passcode_dot_empty)
            }
            dots.add(dot)
            passcodeDotsContainer.addView(dot)
        }
    }

    private fun onDigitEntered(digit: Int) {
        if (enteredDigits.length >= 4) return
        enteredDigits.append(digit)
        updateDots()
        if (enteredDigits.length == 4) {
            handler.postDelayed({ checkPasscode() }, 200)
        }
    }

    private fun updateDots() {
        dots.forEachIndexed { index, dot ->
            dot.background = ContextCompat.getDrawable(
                this,
                if (index < enteredDigits.length) R.drawable.passcode_dot_filled
                else R.drawable.passcode_dot_empty
            )
        }
        if (enteredDigits.isNotEmpty()) {
            dots.getOrNull(enteredDigits.length - 1)?.let { dot ->
                dot.animate().scaleX(1.3f).scaleY(1.3f).setDuration(100)
                    .withEndAction {
                        dot.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                    }.start()
            }
        }
    }

    private fun checkPasscode() {
        val entered = enteredDigits.toString()
        if (sha256(entered) == storedHash) {
            onUnlockSuccess()
        } else {
            onUnlockFailed()
        }
    }

    private fun onUnlockSuccess() {
        lockIcon.background = ContextCompat.getDrawable(this, R.drawable.ic_lock_open)
        lockIcon.background?.setTint(ContextCompat.getColor(this, R.color.success_green))

        lockIcon.animate().scaleX(1.2f).scaleY(1.2f).setDuration(200)
            .setInterpolator(OvershootInterpolator())
            .withEndAction {
                lockIcon.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
            }.start()

        successOverlay.visibility = View.VISIBLE
        successOverlay.animate().alpha(1f).setDuration(300).start()

        handler.postDelayed({
            setResult(Activity.RESULT_OK)
            finish()
        }, 1_200)
    }

    private fun onUnlockFailed() {
        ObjectAnimator.ofFloat(passcodeDotsContainer, "translationX",
                               0f, -20f, 20f, -20f, 20f, 0f).apply {
            duration = 400; start()
        }
        ObjectAnimator.ofFloat(lockIcon, "translationX",
                               0f, -10f, 10f, -10f, 10f, 0f).apply {
            duration = 400; start()
        }
        dots.forEach { dot ->
            dot.background = ContextCompat.getDrawable(this, R.drawable.passcode_dot_error)
        }
        handler.postDelayed({ resetPasscode() }, 400)
    }

    private fun resetPasscode() {
        enteredDigits.clear()
        dots.forEach { it.background = ContextCompat.getDrawable(this, R.drawable.passcode_dot_empty) }
        rotaryDialView.reset()
    }

    private fun updateClock() {
        val cal = Calendar.getInstance()
        clockText.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(cal.time)
        dateText.text  = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(cal.time)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(clockRunnable)
    }
}
